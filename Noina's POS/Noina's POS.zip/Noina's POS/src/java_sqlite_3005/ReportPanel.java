package java_sqlite_3005;

import java.awt.*;
import javax.swing.*;

// This is the Panel that contains represents the view of the
// Music Store

public class ReportPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private JTextArea 		text;
	
	public Font getUIFont() {
		return UIFont;
	}
	

	private Font UIFont = new Font("Courier New", Font.BOLD, 16);

	// These are the get methods that are used to access the components

	// This is the default constructor
	public ReportPanel(){
		super();

		// Use a GridBagLayout (lotsa fun)
		GridBagLayout layout = new GridBagLayout();
		GridBagConstraints layoutConstraints = new GridBagConstraints();
		setLayout(layout);
	
		text = new JTextArea();

		layoutConstraints.gridx = 0;
		layoutConstraints.gridy = 0;
		layoutConstraints.gridwidth = 3;
		layoutConstraints.gridheight = 1;
		layoutConstraints.fill = GridBagConstraints.BOTH;
		layoutConstraints.insets = new Insets(0, 0, 0, 0);
		layoutConstraints.anchor = GridBagConstraints.EAST;
		layoutConstraints.weightx = 1.0;
		layoutConstraints.weighty = 1.0;
		layout.setConstraints(text, layoutConstraints);
		add(text);
		
		JScrollPane pane = new JScrollPane(text);
		layoutConstraints.gridx = 0;
		layoutConstraints.gridy = 0;
		layoutConstraints.gridwidth = 3;
		layoutConstraints.gridheight = 1;
		layoutConstraints.fill = GridBagConstraints.BOTH;
		layoutConstraints.insets = new Insets(0, 0, 0, 0);
		layoutConstraints.anchor = GridBagConstraints.EAST;
		layoutConstraints.weightx = 1.0;
		layoutConstraints.weighty = 1.0;
		layout.setConstraints(pane, layoutConstraints);
	    add(pane);
		
	}

	public JTextArea getText() {
		return text;
	}
	

}