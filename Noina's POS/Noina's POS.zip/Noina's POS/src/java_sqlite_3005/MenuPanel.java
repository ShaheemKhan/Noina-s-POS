package java_sqlite_3005;

import java.awt.*;

import javax.swing.*;

// This is the Panel that contains represents the view of the
// Music Store

public class MenuPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	// These are the components
	private JButton		posButton;
	private JButton		inventoryManButton;
	private JButton		cashButton;

	private JButton		reportsButton;


	


	public JButton getCashButton() {
		return cashButton;
	}


	public JButton getPosButton() {
		return posButton;
	}


	public JButton getInventoryManButton() {
		return inventoryManButton;
	}


	public JButton getReportsButton() {
		return reportsButton;
	}


	public Font getUIFont() {
		return UIFont;
	}

	private Font UIFont = new Font("Courier New", Font.BOLD, 16);


	public MenuPanel(){
		super();

		// Use a GridBagLayout (lotsa fun)
		GridBagLayout layout = new GridBagLayout();
		GridBagConstraints layoutConstraints = new GridBagConstraints();
		setLayout(layout);
		
		posButton = new JButton("Point of Sale");
		layoutConstraints.gridx = 0;
		layoutConstraints.gridy = 0;
		layoutConstraints.gridwidth = 1;
		layoutConstraints.gridheight = 1;
		layoutConstraints.fill = GridBagConstraints.BOTH;
		layoutConstraints.insets = new Insets(0, 0, 0, 0);
		layoutConstraints.anchor = GridBagConstraints.EAST;
		layoutConstraints.weightx = 0.0;
		layoutConstraints.weighty = 0;
		layout.setConstraints(posButton, layoutConstraints);
		add(posButton);
		
		inventoryManButton = new JButton("Inventory Management");
		layoutConstraints.gridx = 1;
		layoutConstraints.gridy = 0;
		layoutConstraints.gridwidth = 1;
		layoutConstraints.gridheight = 1;
		layoutConstraints.fill = GridBagConstraints.BOTH;
		layoutConstraints.insets = new Insets(0, 0, 0, 0);
		layoutConstraints.anchor = GridBagConstraints.EAST;
		layoutConstraints.weightx = 0.0;
		layoutConstraints.weighty = 0;
		layout.setConstraints(inventoryManButton, layoutConstraints);
		add(inventoryManButton);
		
		cashButton = new JButton("Cash");
		layoutConstraints.gridx = 2;
		layoutConstraints.gridy = 0;
		layoutConstraints.gridwidth = 1;
		layoutConstraints.gridheight = 1;
		layoutConstraints.fill = GridBagConstraints.BOTH;
		layoutConstraints.insets = new Insets(0, 0, 0, 0);
		layoutConstraints.anchor = GridBagConstraints.EAST;
		layoutConstraints.weightx = 0.0;
		layoutConstraints.weighty = 0;
		layout.setConstraints(cashButton, layoutConstraints);
		add(cashButton);
	
		reportsButton = new JButton("Reports");
		layoutConstraints.gridx = 3;
		layoutConstraints.gridy = 0;
		layoutConstraints.gridwidth = 1;
		layoutConstraints.gridheight = 1;
		layoutConstraints.fill = GridBagConstraints.BOTH;
		layoutConstraints.insets = new Insets(0, 0, 0, 0);
		layoutConstraints.anchor = GridBagConstraints.EAST;
		layoutConstraints.weightx = 0.0;
		layoutConstraints.weighty = 0;
		layout.setConstraints(reportsButton, layoutConstraints);
		add(reportsButton);
	}
}