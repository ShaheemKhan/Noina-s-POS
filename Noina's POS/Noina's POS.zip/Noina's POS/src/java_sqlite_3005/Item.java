package java_sqlite_3005;

public class Item {
	/*
	 * This class represents a fake book
	 */
	
	private String barcode;
	private int quantity;
	private int price;
	private String fullName;
	

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public Item(String bc, int qu, int pr, String fn){ 
		barcode = bc; 
		quantity = qu;
		price = pr;
		fullName = fn;
	}
	
	public Item(String bc){ 
		barcode = bc; 
	}

	public String getBarcode() {
		return barcode;
	}


	public int getQuantity() {
		return quantity;
	}

	public int getPrice() {
		return price;
	}

	public String getFullName() {
		return fullName;
	}
	
	public String toString(){
		return "Barcode: " + barcode + " Quantity: " + quantity;
	}
}
