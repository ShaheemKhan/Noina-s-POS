package java_sqlite_3005;

import java.util.Vector;
import javax.swing.table.AbstractTableModel;

class Statement extends AbstractTableModel {

	private static final long serialVersionUID = 1L;

	private String[] columnNames = {
			"Description",
			"Quantity"};
	private Vector<Object[]> data;


	public void setColumnNames(String[] columnNames) {
		this.columnNames = columnNames;
	}

	public void setData(Vector<Object[]> data) {
		this.data = data;
	}

	public Statement() {
		data = new Vector<Object[]>();
	}

	public String[] getColumnNames() {
		return columnNames;
	}

	public Vector<Object[]> getData() {
		return data;
	}

	public int getColumnCount() {
		return columnNames.length;
	}

	public int getRowCount() {
		return data.size();
	}

	public String getColumnName(int col) {
		return columnNames[col];
	}

	public Object getValueAt(int row, int col) {
		return data.get(row)[col];
	}


	/*
	 * Don't need to implement this method unless your table's
	 * editable.
	 */
	public boolean isCellEditable(int row, int col) {  	
		return false;
	}

	/*
	 * Don't need to implement this method unless your table's
	 * data can change.
	 */
	public void setValueAt(Object value, int row, int col) {
		data.get(row)[col] = value;
		if (col==2)
			fireTableCellUpdated(row, col);
	}
}