package java_sqlite_3005;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.text.NumberFormat;

import javax.swing.*;
import javax.swing.text.NumberFormatter;

public class NewItemDialog extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// This is a pointer to the email buddy that is being edited
	private Item item;

	DialogClient theDialogClient;

	// These are the components of the dialog box
	private JLabel					aLabel; //reuseable label variable

	private JTextField				titleField; 
	private JFormattedTextField		quantityField;

	

	private JButton					updateButton;
	private JButton					cancelButton;

	Font UIFont = new Font("Courier New", Font.BOLD, 16);



	public NewItemDialog(Frame owner, DialogClient aClient, String title, boolean modal, Item aItem){
		super(owner,title,modal);

		//Store the client and model variables
		theDialogClient = aClient;
		item = aItem;

		// Put all the components onto the window and given them initial values
		buildDialogWindow(item);

		// Add listeners for the Ok and Cancel buttons as well as window closing
		updateButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event){
				updateButtonClicked();
			}});

		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event){
				cancelButtonClicked();
			}});

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent event) {
				cancelButtonClicked();
			}});

		setSize(400, 400);


	}

	// This code adds the necessary components to the interface
	private void buildDialogWindow(Item aItem) {

		GridBagLayout layout = new GridBagLayout();
		GridBagConstraints lc = new GridBagConstraints();
		getContentPane().setLayout(layout);


		lc.anchor = GridBagConstraints.EAST;
		lc.insets = new Insets(5, 5, 5, 5);

		aLabel = new JLabel("Barcode: ");
		lc.gridx = 0; lc.gridy = 0;
		lc.gridwidth = 1; lc.gridheight = 1;
		lc.weightx = 0.0; lc.weighty = 0.0;
		layout.setConstraints(aLabel, lc);
		getContentPane().add(aLabel);
		
		aLabel = new JLabel("Quantity: ");
		lc.gridx = 0; lc.gridy = 1;
		lc.gridwidth = 1; lc.gridheight = 1;
		lc.weightx = 0.0; lc.weighty = 0.0;
		layout.setConstraints(aLabel, lc);
		getContentPane().add(aLabel);
		

		// Add the name field
		titleField = new JTextField(aItem.getBarcode());
		titleField.setFont(UIFont);
		lc.gridx = 1; lc.gridy = 0;
		lc.gridwidth = 3; lc.gridheight = 1;
		lc.fill = GridBagConstraints.BOTH;
		lc.weightx = 1.0; lc.weighty = 0.0;
		layout.setConstraints(titleField, lc);
		getContentPane().add(titleField);
		titleField.setEditable(false);
		
	    NumberFormat format = NumberFormat.getInstance();
	    NumberFormatter formatter = new NumberFormatter(format);
	    formatter.setValueClass(Integer.class);
	    formatter.setMinimum(0);
	    formatter.setMaximum(Integer.MAX_VALUE);
	    formatter.setCommitsOnValidEdit(true);

	    quantityField = new JFormattedTextField(formatter);
		quantityField.setFont(UIFont);
		quantityField.setText("0");
		lc.gridx = 1; lc.gridy = 1;
		lc.gridwidth = 3; lc.gridheight = 1;
		lc.fill = GridBagConstraints.BOTH;
		lc.weightx = 1.0; lc.weighty = 0.0;
		layout.setConstraints(quantityField, lc);
		getContentPane().add(quantityField);

		// Add the Update button
		updateButton = new JButton("ADD NEW");

		lc.gridx = 1; lc.gridy = 4;
		lc.gridwidth = 1; lc.gridheight = 1;
		lc.weightx = 0.0; lc.weighty = 0.0;
		layout.setConstraints(updateButton, lc);
		getContentPane().add(updateButton);


		// Add the Cancel button
		cancelButton = new JButton("CANCEL");

		lc.gridx = 3; lc.gridy = 4;
		lc.gridwidth = 1; lc.gridheight = 1;
		lc.weightx = 0.0; lc.weighty = 0.0;
		layout.setConstraints(cancelButton, lc);
		getContentPane().add(cancelButton);


	}


	private void updateButtonClicked() {
		String passwordValue = "";
		int result = 1000;
		//Here is some validation code
		while (true) {
			if (passwordValue.equals("abcd1234")) {
				break;
			}
			if (result == JOptionPane.CANCEL_OPTION) {
				return;
			}
			JLabel jPassword = new JLabel("Password");
			JTextField password = new JPasswordField();
			Object[] ob = {jPassword, password};
			result = JOptionPane.showConfirmDialog(null, ob, "Enter Your Password", JOptionPane.OK_CANCEL_OPTION);
			passwordValue = password.getText();
			if (passwordValue.equals("abcd1234")) {
				break;
			}
			if (result == JOptionPane.CANCEL_OPTION) {
				return;
			}
		}
		
	//	item.setQuantity(Integer.parseInt(quantityField.getText().replaceAll(",", "")));	
		item.setPrice(Integer.parseInt(quantityField.getText().replaceAll(",", "")));		

		if (theDialogClient != null)
			try {
				theDialogClient.dialogFinished(DialogClient.operation.ADD);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		dispose();
	}

	private void cancelButtonClicked(){
		if (theDialogClient != null) 
			theDialogClient.dialogCancelled();
		dispose();
	}
}