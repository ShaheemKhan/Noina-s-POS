package java_sqlite_3005;

import java.awt.*;

import javax.swing.*;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;

// This is the Panel that contains represents the view of the
// Music Store

public class PosPanel extends JPanel {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    // These are the components
    private JLabel      billNumber;
    private JButton     submitButton;
    private JButton     changeViewButton;
    private JButton     addItemButton;
    private JTable      table;



    public JButton getsubmitButton() {
        return submitButton;
    }

    public JLabel getBillNumber() {
        return billNumber;
    }
    public JButton getAddItemButton() {
        return addItemButton;
    }

    public JButton getChangeViewButton() {
        return changeViewButton;
    }
    public void setChangeViewButton(JButton changeViewButton) {
        this.changeViewButton = changeViewButton;
    }
    public JTable getTable() {
        return table;
    }

    public PosPanel(){
        super();

        // Use a GridBagLayout (lotsa fun)
        GridBagLayout layout = new GridBagLayout();
        GridBagConstraints layoutConstraints = new GridBagConstraints();
        setLayout(layout);

        billNumber = new JLabel("Invoice #1");
        layoutConstraints.gridx = 0;
        layoutConstraints.gridy = 0;
        layoutConstraints.gridwidth = 1;
        layoutConstraints.gridheight = 1;
        layoutConstraints.fill = GridBagConstraints.BOTH;
        layoutConstraints.insets = new Insets(10, 10, 10, 10);
        layoutConstraints.anchor = GridBagConstraints.EAST;
        layoutConstraints.weightx = 1.0;
        layoutConstraints.weighty = 0.05;
        layout.setConstraints(billNumber, layoutConstraints);
        add(billNumber);

        changeViewButton = new JButton("Exchange/Return");
        layoutConstraints.gridx = 1;
        layoutConstraints.gridy = 0;
        layoutConstraints.gridwidth = 1;
        layoutConstraints.gridheight = 1;
        layoutConstraints.fill = GridBagConstraints.BOTH;
        layoutConstraints.insets = new Insets(0, 0, 0, 0);
        layoutConstraints.anchor = GridBagConstraints.EAST;
        layoutConstraints.weightx = 1.0;
        layoutConstraints.weighty = 0.05;
        layout.setConstraints(changeViewButton, layoutConstraints);
        add(changeViewButton);

        addItemButton = new JButton("Add Item");
        layoutConstraints.gridx = 2;
        layoutConstraints.gridy = 0;
        layoutConstraints.gridwidth = 1;
        layoutConstraints.gridheight = 1;
        layoutConstraints.fill = GridBagConstraints.BOTH;
        layoutConstraints.insets = new Insets(0, 0, 0, 0);
        layoutConstraints.anchor = GridBagConstraints.EAST;
        layoutConstraints.weightx = 1.0;
        layoutConstraints.weighty = 0.05;
        layout.setConstraints(addItemButton, layoutConstraints);
        add(addItemButton);

        submitButton = new JButton("Submit");
        layoutConstraints.gridx = 0;
        layoutConstraints.gridy = 5;
        layoutConstraints.gridwidth = 3;
        layoutConstraints.gridheight = 1;
        layoutConstraints.fill = GridBagConstraints.BOTH;
        layoutConstraints.insets = new Insets(0, 0, 0, 0);
        layoutConstraints.anchor = GridBagConstraints.EAST;
        layoutConstraints.weightx = 1.0;
        layoutConstraints.weighty = 0.05;
        layout.setConstraints(submitButton, layoutConstraints);
        add(submitButton);



        table = new JTable(new MyTableModel());
        
        int[] alignments = new int[] { JLabel.LEFT, JLabel.CENTER, JLabel.RIGHT };
        table.getTableHeader().getColumnModel().getColumn(0)
        .setHeaderRenderer(new HeaderRenderer(table, alignments[0]));
        table.getTableHeader().getColumnModel().getColumn(2)
        .setHeaderRenderer(new HeaderRenderer(table, alignments[1]));

        table.getTableHeader().setFont(new Font("Times New Roman", Font.BOLD, 28));
        table.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        table.getColumnModel().getColumn(0).setMinWidth(350);
        table.getColumnModel().getColumn(0).setMaxWidth(350);
        table.getColumnModel().getColumn(2).setMinWidth(135);
        table.getColumnModel().getColumn(2).setMaxWidth(135);
        table.getColumnModel().getColumn(3).setMinWidth(125);
        table.getColumnModel().getColumn(3).setMaxWidth(125);
        table.getColumnModel().getColumn(4).setMinWidth(155);
        table.getColumnModel().getColumn(4).setMaxWidth(155);
        table.setRowHeight(30);

        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(DefaultTableCellRenderer.CENTER);
        table.getColumn("Quantity").setCellRenderer( rightRenderer );       
        table.getColumn("Price").setCellRenderer( rightRenderer );      
        table.getColumn("Item Total").setCellRenderer( rightRenderer );     

        table.setShowGrid(true);
        Color color = Color.black;
        MatteBorder border = new MatteBorder(1, 1, 0, 0, color);
        table.setBorder(border);
        table.setGridColor(color);
        table.setFillsViewportHeight(true);
                
        JScrollPane pane = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        layoutConstraints.gridx = 0;
        layoutConstraints.gridy = 3;
        layoutConstraints.gridwidth = 3;
        layoutConstraints.gridheight = 1;
        layoutConstraints.fill = GridBagConstraints.BOTH;
        layoutConstraints.insets = new Insets(0, 0, 0, 0);
        layoutConstraints.anchor = GridBagConstraints.EAST;
        layoutConstraints.weightx = 1.0;
        layoutConstraints.weighty = 1.0;
        layout.setConstraints(pane, layoutConstraints);


        add(pane);    
    }

    public void tableReset() {

        table.setModel(new MyTableModel());

        int[] alignments = new int[] { JLabel.LEFT, JLabel.CENTER, JLabel.RIGHT };
        table.getTableHeader().getColumnModel().getColumn(0)
        .setHeaderRenderer(new HeaderRenderer(table, alignments[0]));

        table.getTableHeader().getColumnModel().getColumn(2)
        .setHeaderRenderer(new HeaderRenderer(table, alignments[1]));

        table.getTableHeader().setFont(new Font("Times New Roman", Font.BOLD, 28));
        table.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        table.getColumnModel().getColumn(0).setMinWidth(350);
        table.getColumnModel().getColumn(0).setMaxWidth(350);
        table.getColumnModel().getColumn(2).setMinWidth(135);
        table.getColumnModel().getColumn(2).setMaxWidth(135);
        table.getColumnModel().getColumn(3).setMinWidth(125);
        table.getColumnModel().getColumn(3).setMaxWidth(125);
        table.getColumnModel().getColumn(4).setMinWidth(155);
        table.getColumnModel().getColumn(4).setMaxWidth(155);
        table.setRowHeight(30);

        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(DefaultTableCellRenderer.CENTER);
        table.getColumn("Quantity").setCellRenderer( rightRenderer );       
        table.getColumn("Price").setCellRenderer( rightRenderer );      
        table.getColumn("Item Total").setCellRenderer( rightRenderer );     
    }

    private static class HeaderRenderer implements TableCellRenderer {
        DefaultTableCellRenderer renderer;
        int horAlignment;
        public HeaderRenderer(JTable table, int horizontalAlignment) {
            horAlignment = horizontalAlignment;
            renderer = (DefaultTableCellRenderer)table.getTableHeader()
                    .getDefaultRenderer();
        }
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int col) {
            Component c = renderer.getTableCellRendererComponent(table, value,
                    isSelected, hasFocus, row, col);
            JLabel label = (JLabel)c;
            label.setHorizontalAlignment(horAlignment);
            return label;
        }
    }
}