	package java_sqlite_3005;


import java.awt.event.WindowAdapter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.UIManager;

public class javaWithSQliteMain {

	public static void main(String[] args) throws FileNotFoundException, IOException {

		
		// TODO Auto-generated method stub
		System.out.println("Java With SQLite example");
		GUI frame = null;
		try {

			Class.forName("org.sqlite.JDBC");
			Connection database = DriverManager
					.getConnection("jdbc:sqlite:noina");
			Statement stat = database.createStatement();
			
			String sqlQueryString = "select * from inventory;";
			System.out.println(sqlQueryString);

			ArrayList<Item> inventory = new ArrayList<Item>();

			ResultSet rs = stat.executeQuery(sqlQueryString);
			while (rs.next()) {
				Item it = new Item(rs.getString("item_barcode"), 
						rs.getInt("item_quantity"),
						rs.getInt("item_price"),
						rs.getString("item_full_name"));
				inventory.add(it);
			}
			rs.close(); 
			
		frame = new GUI("Noina's POS", database, stat, inventory);

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// make GUI visible
		frame.setVisible(true);
	    
	}


}