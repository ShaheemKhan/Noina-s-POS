package java_sqlite_3005;

import java.text.DateFormatSymbols;

public class Invoice {
	/*
	 * This class represents a fake book
	 */
	
	private int id; 
	private int day;
	private int month;
	private int year;
	private String time;
	private int total;

	public Invoice(int bc, int sn, int ty, int si, String t, int qu){ 
		id = bc; 
		day = sn;
		month = ty;
		time = t;
		year = si;
		total = qu;
	}

	public String toString(){
		return "Invoice #" + id + " Total: AED " + total + " @ " + day + 
				"/" + new DateFormatSymbols().getMonths()[month] + "/" + year
				 + " " + time;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getId() {
		return id;
	}

	public int getDay() {
		return day;
	}

	public int getMonth() {
		return month;
	}

	public int getYear() {
		return year;
	}

	public int getTotal() {
		return total;
	}
}
