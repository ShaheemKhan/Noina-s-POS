package java_sqlite_3005;

import java.util.Vector;

import javax.swing.table.AbstractTableModel;

class MyTableModel extends AbstractTableModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String[] columnNames = {"Barcode",
			"Description",
			"Quantity",
			"Price",
	"Item Total"};
	private Vector<Object[]> data;
	private int till;
	public int getTill() {
		return till;
	}

	public void setTill(int till) {
		this.till = till;
	}

	public void setColumnNames(String[] columnNames) {
		this.columnNames = columnNames;
	}

	public void setData(Vector<Object[]> data) {
		this.data = data;
	}

	public MyTableModel() {
		till = -1;
		data = new Vector<Object[]>();

	}

	public String[] getColumnNames() {
		return columnNames;
	}

	public Vector<Object[]> getData() {
		return data;
	}

	public void updateTotal(Object[] a) {
		if (getRowCount() > 0) {
			data.remove(getRowCount()-1);
		}
		data.add(a);



		Integer total  = 0;
		for (int i = 0; i < getRowCount(); i++) {
			Integer q = (Integer) getValueAt(i, 2);
			Integer cp = (Integer) getValueAt(i, 3);
			setValueAt(new CurrencyAED(cp*q), i, 4);
			total += cp*q;
		}	

		Object[] t = {"", "", "", "", new CurrencyAED(total)};
		data.add(t);

	}


	public void updateTotalTill(Object[] a) {
		if (getRowCount() - till - 1> 0) {
			data.remove(getRowCount()-1);
			data.remove(getRowCount()-1);
			data.remove(getRowCount()-1);
		}


		data.add(a);

		Integer total  = 0;

		for (int i = till+1; i < getRowCount(); i++) {
			Integer q = (Integer) getValueAt(i, 2);
			Integer cp = (Integer) getValueAt(i, 3);
			setValueAt(new CurrencyAED(cp*q), i, 4);
			total += cp*q;
		}	
		Object[] t = {"", "New Total", "", "", new CurrencyAED(total)};
		data.add(t);
		Object[] j = {"", "Old Total", "", "", getValueAt(till-2, 4)};
		data.add(j);
		int m = ((CurrencyAED)getValueAt(getRowCount()-1, 4)).getValue();
		int f = ((CurrencyAED)getValueAt(getRowCount()-2, 4)).getValue();
		Object[] k = {"", "Difference", "", "",  new CurrencyAED(f-m)};
		data.add(k);


	}

	public void enterBlank() {
		Object[] b = {"", "", "", "", ""};
		data.add(b);
		Object[] c = {"New Receipt", "", "", "", ""};
		data.add(c);
	}


	public int getColumnCount() {
		return columnNames.length;
	}

	public int getRowCount() {
		return data.size();
	}

	public String getColumnName(int col) {
		return columnNames[col];
	}

	public Object getValueAt(int row, int col) {
		return data.get(row)[col];
	}

	public Class getColumnClass(int c) {
		return getValueAt(0, c).getClass();
	}

	/*
	 * Don't need to implement this method unless your table's
	 * editable.
	 */
	public boolean isCellEditable(int row, int col) {  	
		if ((col ==  2 || col ==  3) && (row > till)) {
			return true;
		}
		return false;
	}

	/*
	 * Don't need to implement this method unless your table's
	 * data can change.
	 */
	public void setValueAt(Object value, int row, int col) {
		data.get(row)[col] = value;
		if (col==3)
			fireTableCellUpdated(row, col);
		if (col==2)
			fireTableCellUpdated(row, col);
	}
}