package java_sqlite_3005;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;

public class CurrencyAED {

	public Integer value;

	public int getValue() {
		return value;
	}

	Locale currentLocale = new Locale.Builder().setLanguage("en").setRegion("AE").build();
	NumberFormat nf = NumberFormat.getNumberInstance(currentLocale);
	DecimalFormat df = (DecimalFormat)nf;
	String pattern = "AED #,###,##0.00";
	String patternr = "(AED #,###,##0.00)";


	public CurrencyAED(int v){
		value = v;
		df.applyPattern(pattern);
	}
	
	public CurrencyAED(int v, int k){
		value = v;
		df.applyPattern(patternr);
	}
	
	public String toString() {
		String output = df.format(value);
		return (output);
	}
	
}
