package java_sqlite_3005;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.text.NumberFormat;

import javax.swing.*;
import javax.swing.text.NumberFormatter;

public class ExpensesDialog extends JDialog {

	private static final long serialVersionUID = 1L;

	// This is a pointer to the email buddy that is being edited

	private Cash c;
	DialogClient theDialogClient;

	// These are the components of the dialog box
	private JLabel					aLabel; //reuseable label variable

	private JTextField				amountField; 
	private JTextField				descField;
	private JTextField				userField;
	private JButton					sumbitButton;

	Font UIFont = new Font("Courier New", Font.BOLD, 16);



	public ExpensesDialog(Frame owner, DialogClient aClient, String title, boolean modal, Cash cc){
		super(owner,title,modal);

		//Store the client and model variables
		theDialogClient = aClient;

		// Put all the components onto the window and given them initial values
		buildDialogWindow();

		// Add listeners for the Ok and Cancel buttons as well as window closing
		sumbitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event){
				sumbitButtonClicked();
			}});

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent event) {
				cancelButtonClicked();
			}});

		setSize(400, 400);
		c = cc;

	}

	// This code adds the necessary components to the interface
	private void buildDialogWindow() {

		GridBagLayout layout = new GridBagLayout();
		GridBagConstraints lc = new GridBagConstraints();
		getContentPane().setLayout(layout);


		lc.anchor = GridBagConstraints.EAST;
		lc.insets = new Insets(5, 5, 5, 5);

		aLabel = new JLabel("Amount: ");
		lc.gridx = 0; lc.gridy = 0;
		lc.gridwidth = 1; lc.gridheight = 1;
		lc.weightx = 0.0; lc.weighty = 0.0;
		layout.setConstraints(aLabel, lc);
		getContentPane().add(aLabel);

		aLabel = new JLabel("Description: ");
		lc.gridx = 0; lc.gridy = 1;
		lc.gridwidth = 1; lc.gridheight = 1;
		lc.weightx = 0.0; lc.weighty = 0.0;
		layout.setConstraints(aLabel, lc);
		getContentPane().add(aLabel);

		aLabel = new JLabel("By: ");
		lc.gridx = 0; lc.gridy = 2;
		lc.gridwidth = 1; lc.gridheight = 1;
		lc.weightx = 0.0; lc.weighty = 0.0;
		layout.setConstraints(aLabel, lc);
		getContentPane().add(aLabel);

		NumberFormat format = NumberFormat.getInstance();
		NumberFormatter formatter = new NumberFormatter(format);
		formatter.setValueClass(Integer.class);
		formatter.setMinimum(0);
		formatter.setMaximum(Integer.MAX_VALUE);
		formatter.setCommitsOnValidEdit(true);

		amountField = new JFormattedTextField(formatter);
		amountField.setFont(UIFont);
		lc.gridx = 1; lc.gridy = 0;
		lc.gridwidth = 3; lc.gridheight = 1;
		lc.fill = GridBagConstraints.BOTH;
		lc.weightx = 1.0; lc.weighty = 0.0;
		layout.setConstraints(amountField, lc);
		getContentPane().add(amountField);

		// Add the address field
		descField = new JTextField();
		descField.setFont(UIFont);
		lc.gridx = 1; lc.gridy = 1;
		lc.gridwidth = 3; lc.gridheight = 1;
		lc.fill = GridBagConstraints.BOTH;
		lc.weightx = 1.0; lc.weighty = 0.0;
		layout.setConstraints(descField, lc);
		getContentPane().add(descField);

		// Add the year field
		userField = new JTextField();
		userField.setFont(UIFont);
		lc.gridx = 1; lc.gridy = 2;
		lc.gridwidth = 3; lc.gridheight = 1;
		lc.fill = GridBagConstraints.BOTH;
		lc.weightx = 1.0; lc.weighty = 0.0;
		layout.setConstraints(userField, lc);
		getContentPane().add(userField);


		// Add the Update button
		sumbitButton = new JButton("Submit");

		lc.gridx = 1; lc.gridy = 7;
		lc.gridwidth = 1; lc.gridheight = 1;
		lc.weightx = 1.0; lc.weighty = 0.0;
		layout.setConstraints(sumbitButton, lc);
		getContentPane().add(sumbitButton);

	}


	private void sumbitButtonClicked() {
		if (!(amountField.getText().equals("")) && !(descField.getText().equals("")) &&
				!(userField.getText().equals(""))){
			c.setWitdr_amount(Integer.parseInt(amountField.getText().replaceAll(",", "")));
			c.setWitdr_desc(descField.getText().replaceAll(",", ""));
			c.setWitdr_user(userField.getText().replaceAll(",", ""));
			
			try {
				theDialogClient.dialogFinished(DialogClient.operation.EXPENSE);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			dispose();
		}
	}

	private void cancelButtonClicked(){
		if (theDialogClient != null) 
			theDialogClient.dialogCancelled();
		dispose();
	}
}