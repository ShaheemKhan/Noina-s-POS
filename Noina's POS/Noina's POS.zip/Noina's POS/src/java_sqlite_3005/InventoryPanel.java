package java_sqlite_3005;

import java.awt.*;

import javax.swing.*;

// This is the Panel that contains represents the view of the
// Music Store

public class InventoryPanel extends JPanel {


	private static final long serialVersionUID = 1L;

	// These are the components
//	private JTextField	searchField;
	private JButton		searchButton;
	private JLabel		itemBarcode;
	private JLabel 		itemQuantity;
	private JLabel 		itemPrice;
	private JLabel 		itemFullName;
	private JButton		itemEditButton;
	private JButton		itemNewButton;
	private JButton		itemDeleteButton;


	
	public JLabel getItemFullName() {
		return itemFullName;
	}
	public JButton getItemEditButton() {
		return itemEditButton;
	}
	public JButton getItemNewButton() {
		return itemNewButton;
	}
	public Font getUIFont() {
		return UIFont;
	}
	public JLabel getItemBarcode() {
		return itemBarcode;
	}
	public JLabel getItemQuantity() {
		return itemQuantity;
	}
	public JLabel getItemPrice() {
		return itemPrice;
	}
	public JLabel getitemFullName() {
		return itemFullName;
	}

	private Font UIFont = new Font("Courier New", Font.BOLD, 16);

	// These are the get methods that are used to access the components
	public JButton getSearchButton() { return searchButton; }

	// This is the default constructor
	public InventoryPanel(){
		super();

		// Use a GridBagLayout (lotsa fun)
		GridBagLayout layout = new GridBagLayout();
		GridBagConstraints layoutConstraints = new GridBagConstraints();
		setLayout(layout);
		
		searchButton = new JButton("Search");
		layoutConstraints.gridx = 0;
		layoutConstraints.gridy = 0;
		layoutConstraints.gridwidth = 1;
		layoutConstraints.gridheight = 1;
		layoutConstraints.fill = GridBagConstraints.BOTH;
		layoutConstraints.insets = new Insets(0, 0, 0, 0);
		layoutConstraints.anchor = GridBagConstraints.EAST;
		layoutConstraints.weightx = 1.0;
		layoutConstraints.weighty = 1.0;
		layout.setConstraints(searchButton, layoutConstraints);
		add(searchButton);
		
		itemBarcode = new JLabel("Barcode: ");
		layoutConstraints.gridx = 0;
		layoutConstraints.gridy = 1;
		layoutConstraints.gridwidth = 1;
		layoutConstraints.gridheight = 1;
		layoutConstraints.fill = GridBagConstraints.BOTH;
		layoutConstraints.insets = new Insets(10, 10, 10, 10);
		layoutConstraints.anchor = GridBagConstraints.EAST;
		layoutConstraints.weightx = 1.0;
		layoutConstraints.weighty = 1.0;
		layout.setConstraints(itemBarcode, layoutConstraints);
		add(itemBarcode);
		
		itemQuantity = new JLabel("Quantity: ");
		layoutConstraints.gridx = 0;
		layoutConstraints.gridy = 2;
		layoutConstraints.gridwidth = 1;
		layoutConstraints.gridheight = 1;
		layoutConstraints.fill = GridBagConstraints.BOTH;
		layoutConstraints.insets = new Insets(10, 10, 10, 10);
		layoutConstraints.anchor = GridBagConstraints.EAST;
		layoutConstraints.weightx = 1.0;
		layoutConstraints.weighty = 1.0;
		layout.setConstraints(itemQuantity, layoutConstraints);
		add(itemQuantity);

		itemPrice = new JLabel("Price: ");
		layoutConstraints.gridx = 0;
		layoutConstraints.gridy = 3;
		layoutConstraints.gridwidth = 1;
		layoutConstraints.gridheight = 1;
		layoutConstraints.fill = GridBagConstraints.BOTH;
		layoutConstraints.insets = new Insets(10, 10, 10, 10);
		layoutConstraints.anchor = GridBagConstraints.EAST;
		layoutConstraints.weightx = 1.0;
		layoutConstraints.weighty = 1.0;
		layout.setConstraints(itemPrice, layoutConstraints);
		add(itemPrice);
		
		itemFullName = new JLabel("Full Name: ");
		layoutConstraints.gridx = 0;
		layoutConstraints.gridy = 4;
		layoutConstraints.gridwidth = 1;
		layoutConstraints.gridheight = 1;
		layoutConstraints.fill = GridBagConstraints.BOTH;
		layoutConstraints.insets = new Insets(10, 10, 10, 10);
		layoutConstraints.anchor = GridBagConstraints.EAST;
		layoutConstraints.weightx = 1.0;
		layoutConstraints.weighty = 1.0;
		layout.setConstraints(itemFullName, layoutConstraints);
		add(itemFullName);

		itemEditButton = new JButton("Edit Item");
		layoutConstraints.gridx = 0;
		layoutConstraints.gridy = 5;
		layoutConstraints.gridwidth = 1;
		layoutConstraints.gridheight = 1;
		layoutConstraints.fill = GridBagConstraints.BOTH;
		layoutConstraints.insets = new Insets(0, 0, 0, 0);
		layoutConstraints.anchor = GridBagConstraints.EAST;
		layoutConstraints.weightx = 1.0;
		layoutConstraints.weighty = 1.0;
		layout.setConstraints(itemEditButton, layoutConstraints);
		itemEditButton.setEnabled(false);
		add(itemEditButton);
		
		itemNewButton = new JButton("Add Stock");
		layoutConstraints.gridx = 1;
		layoutConstraints.gridy = 0;
		layoutConstraints.gridwidth = 1;
		layoutConstraints.gridheight = 1;
		layoutConstraints.fill = GridBagConstraints.BOTH;
		layoutConstraints.insets = new Insets(0, 0, 0, 0);
		layoutConstraints.anchor = GridBagConstraints.EAST;
		layoutConstraints.weightx = 1.0;
		layoutConstraints.weighty = 1.0;
		layout.setConstraints(itemNewButton, layoutConstraints);
		itemNewButton.setEnabled(false);
		add(itemNewButton);
		
		itemDeleteButton = new JButton("Delete Item");
		layoutConstraints.gridx = 1;
		layoutConstraints.gridy = 5;
		layoutConstraints.gridwidth = 1;
		layoutConstraints.gridheight = 1;
		layoutConstraints.fill = GridBagConstraints.BOTH;
		layoutConstraints.insets = new Insets(0, 0, 0, 0);
		layoutConstraints.anchor = GridBagConstraints.EAST;
		layoutConstraints.weightx = 1.0;
		layoutConstraints.weighty = 1.0;
		layout.setConstraints(itemDeleteButton, layoutConstraints);
		itemDeleteButton.setEnabled(false);
		add(itemDeleteButton);
	}
	public JButton getItemDeleteButton() {
		return itemDeleteButton;
	}
	
}