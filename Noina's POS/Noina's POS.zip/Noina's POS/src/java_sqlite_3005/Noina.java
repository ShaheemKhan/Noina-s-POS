package java_sqlite_3005;
/*
 * Copyright (c) 1995, 2008, Oracle and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Oracle or the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 


import java.awt.*;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import java.awt.print.*;
import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Noina implements Printable {

	int[] pageBreaks;  // array of page break line positions.
	ArrayList<String>  itemDesc;
	ArrayList<Integer>  itemPrice;
	ArrayList<Integer>  itemQuan;	
	private Paper receiptPaper;
	private double paperHeight = 11.7;
	double leftMargin = 0.0;
	double rightMargin = 0.0;
	double topMargin = 0.0;
	double bottomMargin = 0.0;
	ArrayList<String> textLines;
	ArrayList<String> textLines2;
	ArrayList<String> caseArray;
	int total;
	String timeS;
	int rNum;
	String type;
	
	private void initTextLines() {
		if (textLines == null) {
			textLines = new ArrayList<String>();
			caseArray = new ArrayList<String>();

			textLines.add(" ");
			caseArray.add("4");
			textLines.add(" ");
			caseArray.add("4");
			
			textLines.add("Noina's");
			caseArray.add("5");

			textLines.add(" ");
			textLines.add(" ");
			caseArray.add("4");
			caseArray.add("4");
			
			textLines.add("AED " + total + ".00");
			caseArray.add("6");
			textLines.add(" ");
			textLines.add(" ");
			caseArray.add("4");
			caseArray.add("4");
			
			textLines.add(type + rNum);
			caseArray.add("2");
			
			textLines.add(timeS);
			caseArray.add("3");
			textLines.add(" ");
			caseArray.add("4");

			textLines.add(" ");
			caseArray.add("4");
			
			for (int x = 0; x < itemDesc.size(); x++) {
				String text = itemDesc.get(x);
				AffineTransform affinetransform = new AffineTransform();     
				FontRenderContext frc = new FontRenderContext(affinetransform,true,true);     
				Font font = new Font("Arial", Font.PLAIN, 9);
				int textwidth = (int)(font.getStringBounds(text, frc).getWidth());

				DecimalFormat formatter = new java.text.DecimalFormat("0000.##");
				String s = formatter.format(itemPrice.get(x) * itemQuan.get(x)).replaceAll("\\G0", "  ");

				if (textwidth > 175) {
					String text1 = "";
					String text2 = "";
					String lines[] = text.split(" ");
					for (int m = 0; m < lines.length; m++) {
						if (m < 3) {
							text1 += lines[m] + " ";
						}
						else
							text2 += lines[m] + " ";
					}
					textLines.add(text1);
					caseArray.add("2");
					textLines.add("AED " + s + ".00");
					caseArray.add("02");
					textLines.add(text2);
					caseArray.add("3");
					textLines.add(" Quantity " + itemQuan.get(x) + " @ AED" + itemPrice.get(x) + "pc.");
					caseArray.add("3");
				}
				else {
					textLines.add(text);
					caseArray.add("2");
					textLines.add("AED " + s + ".00");
					caseArray.add("02");
					textLines.add(" Quantity " + itemQuan.get(x) + " @ AED" + itemPrice.get(x) + "pc.");
					caseArray.add("3");
				}
				textLines.add(" ");
				caseArray.add("4");
			}
			
			textLines.add(" ");
			caseArray.add("4");
			textLines.add("Noina Munzir Garments Trading LLC");
			caseArray.add("03");
			textLines.add("Shop# 6, R-5 Red Block, SH. Hamdan Colony");
			caseArray.add("7");
			textLines.add("Al Karama, Dubai Tel: 04-43973511");
			caseArray.add("8");
			textLines.add("http://www.noinas.com");
			caseArray.add("9");
		}
	}
	
	private void initTextLines2() {
		if (textLines2 == null) {
			textLines2 = new ArrayList<String>();
			textLines2.add("The Unifrom Centre");
			textLines2.add("AED 100.00");
		}
	}

	public int print(Graphics g, PageFormat pf, int pageIndex)
			throws PrinterException {
		
		receiptPaper = new Paper();
		receiptPaper.setSize(3.125 * 72.0, paperHeight * 72.0);
		receiptPaper.setImageableArea(leftMargin * 72.0, topMargin * 72.0,
				(3.125 - leftMargin - rightMargin) * 72.0,
				(paperHeight - topMargin - bottomMargin) * 72.0);

		pf.setPaper(receiptPaper);
		int width = 200 , height = 2000;

		BufferedImage bi = new BufferedImage(width, height, BufferedImage.TRANSLUCENT);
		Graphics2D g2d = bi.createGraphics();
		
		Graphics2D g3d = (Graphics2D) g;
		
		g2d.setColor(Color.black);


		g2d.translate(pf.getImageableX(), pf.getImageableY());
		g2d.translate(pf.getImageableX(), pf.getImageableY());
		
		g3d.translate(pf.getImageableX(), pf.getImageableY());
		g3d.translate(pf.getImageableX(), pf.getImageableY());

		Font font = new Font("Arial", Font.PLAIN, 9);
		FontMetrics metrics = g2d.getFontMetrics(font);
		int lineHeight = metrics.getHeight();

		if (pageBreaks == null) {
			initTextLines2();
			initTextLines();
			int linesPerPage = (int)(pf.getImageableHeight()/lineHeight);
			int numBreaks = (textLines.size())/linesPerPage;
			pageBreaks = new int[numBreaks];
			for (int b=0; b<numBreaks; b++) {
				pageBreaks[b] = (b+1)*linesPerPage; 
			}
		}

		if (pageIndex > pageBreaks.length) {
			return NO_SUCH_PAGE;
		}

		int y = 0; 
		int start = (pageIndex == 0) ? 0 : pageBreaks[pageIndex-1];
		int end   = (pageIndex == pageBreaks.length) ? textLines.size() : pageBreaks[pageIndex];

		for (int line=start; line<end; line++) {
			int v = 0;
			y += lineHeight;
			g2d.setFont(new Font("Arial", Font.PLAIN, 9));
			g3d.setFont(new Font("Arial", Font.PLAIN, 9));
			if (caseArray.get(line).equals("1")) {
				g2d.drawString(textLines.get(line), 100, y);
				g3d.drawString(textLines.get(line), 100, y);
			}
			else if (caseArray.get(line).equals("2")) {
				y -= lineHeight;
				g2d.drawString(textLines.get(line), 10, y);
				g3d.drawString(textLines.get(line), 10, y);
				
			}	
			else if (caseArray.get(line).equals("3")) {
				g2d.drawString(textLines.get(line), 15, y);
				g3d.drawString(textLines.get(line), 15, y);
			}
			else if (caseArray.get(line).equals("02")) {
				y -= lineHeight;
				g2d.drawString(textLines.get(line), 150, y);
				g3d.drawString(textLines.get(line), 150, y);
			}
			else if (caseArray.get(line).equals("5")) {
				g2d.setFont(new Font("Brush Script MT", Font.BOLD, 40));
				g2d.drawString(textLines.get(line), 40, y+6);
				g3d.setFont(new Font("Brush Script MT", Font.BOLD, 40));
				g3d.drawString(textLines.get(line), 40, y+6);
				font = new Font("Brush Script MT", Font.BOLD, 40);
				FontMetrics metrics1 = g2d.getFontMetrics(font);
				v = metrics1.stringWidth(textLines.get(line));
				System.out.println(v);
				y += 5;
			}
			else if (caseArray.get(line).equals("6")) {
				font = (new Font("Arial", Font.BOLD, 20));
				FontMetrics metrics1 = g2d.getFontMetrics(font);
				int adv = metrics1.stringWidth(textLines.get(line));
				int l = 95 - (adv/2);

				g2d.setFont(new Font("Arial", Font.BOLD, 20));
				g2d.drawString(textLines.get(line), l, y);
				g3d.setFont(new Font("Arial", Font.BOLD, 20));
				g3d.drawString(textLines.get(line), l, y);

				y +=  5;
			}
			else if (caseArray.get(line).equals("03")) {
				g2d.setFont(new Font("Arial", Font.BOLD, 7));
				g2d.drawString(textLines.get(line), 50, y);
				g3d.setFont(new Font("Arial", Font.BOLD, 7));
				g3d.drawString(textLines.get(line), 50, y);
			}
			else if (caseArray.get(line).equals("7")) {
				g2d.setFont(new Font("Arial", Font.BOLD, 7));
				g2d.drawString(textLines.get(line), 35, y);
				g3d.setFont(new Font("Arial", Font.BOLD, 7));
				g3d.drawString(textLines.get(line), 35, y);
			}
			else if (caseArray.get(line).equals("8")) {
				g2d.setFont(new Font("Arial", Font.BOLD, 7));
				g2d.drawString(textLines.get(line), 50, y);
				g3d.setFont(new Font("Arial", Font.BOLD, 7));
				g3d.drawString(textLines.get(line), 50, y);
			}
			else if (caseArray.get(line).equals("9")) {
				g2d.setFont(new Font("Arial", Font.BOLD, 7));
				g2d.drawString(textLines.get(line), 70, y);
				g3d.setFont(new Font("Arial", Font.BOLD, 7));
				g3d.drawString(textLines.get(line), 70, y);
			}
			else {
				g2d.drawString(textLines.get(line), 0, y);
				g3d.drawString(textLines.get(line), 0, y);
			}
		}		
		try {
			
			ImageIO.write(bi, "PNG", new File("Invoice//Invoice #" + rNum + ".png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return PAGE_EXISTS;
	}

	public Noina(ArrayList<String> a, ArrayList<Integer> b, ArrayList<Integer> c, int t, String ts, int r, String ty) {
		itemDesc = a;
		itemPrice = b;
		itemQuan = c;
		total = t;
		timeS = ts;
		rNum = r;
		type = ty;
		
	}
	
	public int doJob() {
		PrinterJob printJob = PrinterJob.getPrinterJob();
		printJob.setPrintable(this);
		boolean x = printJob.printDialog();
		if (x) {
			try {
				printJob.print();
				return 1;
			} catch (Exception PrintException) {
				PrintException.printStackTrace();
			}
		}
		return 0;
	}
	
}