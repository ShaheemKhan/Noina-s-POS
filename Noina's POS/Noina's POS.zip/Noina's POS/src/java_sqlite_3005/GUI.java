package java_sqlite_3005;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.DefaultTableCellRenderer;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

@SuppressWarnings("serial")
public class GUI extends JFrame implements DialogClient, TableModelListener {

	public int GUI_DISPLAY_LIMIT = 100;
	Connection databaseConnection;
	Statement stat;
	ArrayList<Item> itemList = new ArrayList<Item>();

	InventoryPanel inventoryView; // panel of GUI components for the main window
	PosPanel posView; // panel of GUI components for the main window

	MenuPanel menuView;
	int k = 0;

	ReportPanel reportView;

	CashPanel cashView;

	GUI thisFrame;
	// Here are the component listeners
	ActionListener searchButtonListener;
	ActionListener editButtonListener;
	ActionListener deleteButtonListener;
	ActionListener newButtonListener;
	Cash cc;
	ActionListener addButtonListener;
	ActionListener submitButtonListener;


	ActionListener posButtonListener;
	ActionListener inManButtonListener;
	ActionListener repButtonListener;
	ActionListener cashButtonListener;

	ActionListener expensesListener;
	ActionListener withdrawListener;



	ActionListener changeViewButtonListener;
	GridBagConstraints layoutConstraints;
	GridBagLayout layout;

	Item itemBeingEdited;
	Item newItem;

	int numbers;
	int info;

	int invoiceNum;
	int c;

	public GUI(String title, Connection aDB, Statement aStatement,
			ArrayList<Item> its) {

		super(title);
		databaseConnection = aDB;
		stat = aStatement;

		itemList = its;
		thisFrame = this;

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				try {
					System.out.println("Closing Database Connection");
					databaseConnection.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				System.exit(0);
			}
		});

		cc = new Cash();
		layout = new GridBagLayout();
		layoutConstraints = new GridBagConstraints();
		setLayout(layout);
		menuView = new MenuPanel();
		inventoryView = new InventoryPanel();
		posView = new PosPanel();
		reportView = new ReportPanel();
		cashView = new CashPanel();

		setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);

		layoutConstraints.gridx = 0;
		layoutConstraints.gridy = 0;
		layoutConstraints.gridwidth = 1;
		layoutConstraints.gridheight = 1;
		layoutConstraints.fill = GridBagConstraints.BOTH;
		layoutConstraints.insets = new Insets(0, 0, 0, 0);
		layoutConstraints.anchor = GridBagConstraints.EAST;
		layoutConstraints.weightx = 1.0;
		layoutConstraints.weighty = 0.0;
		layout.setConstraints(menuView, layoutConstraints);

		layoutConstraints.gridx = 0;
		layoutConstraints.gridy = 1;
		layoutConstraints.gridwidth = 1;
		layoutConstraints.gridheight = 5;
		layoutConstraints.fill = GridBagConstraints.BOTH;
		layoutConstraints.insets = new Insets(0, 0, 0, 0);
		layoutConstraints.anchor = GridBagConstraints.EAST;
		layoutConstraints.weightx = 1.0;
		layoutConstraints.weighty = 1.0;
		layout.setConstraints(inventoryView, layoutConstraints);
		layout.setConstraints(posView, layoutConstraints);
		layout.setConstraints(reportView, layoutConstraints);
		layout.setConstraints(cashView, layoutConstraints);

		add(menuView);
		add(posView);

		int value = 0;
		try {
			ResultSet rs = null;
			PreparedStatement prep = databaseConnection.prepareStatement
					("select seq from sqlite_sequence where name=\"invoice\"");
			rs = prep.executeQuery();

			databaseConnection.setAutoCommit(false);
			databaseConnection.setAutoCommit(true);
			while (rs.next()){	
				value = rs.getInt("seq") + 1;
			}
			rs.close(); //close the query result table	
		} catch (SQLException e) {
			e.printStackTrace();
		}

		posView.getBillNumber().setText("Invoice #" + value);


		menuView.getPosButton().setEnabled(false);
		menuView.getInventoryManButton().setEnabled(true);
		menuView.getReportsButton().setEnabled(true);
		menuView.getCashButton().setEnabled(true);

		withdrawListener = new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				WithdrawDialog dialog = new WithdrawDialog(thisFrame, thisFrame, "Withdraw Cash", true, cc);         
				dialog.setVisible(true);
			}
		};

		expensesListener = new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				ExpensesDialog dialog = new ExpensesDialog(thisFrame, thisFrame, "Add Expenses",true, cc);         
				dialog.setVisible(true);
			}
		};

		changeViewButtonListener = new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				disableListeners();
				enableListeners();

				posView.tableReset();
				if (posView.getChangeViewButton().getText().equals("Exchange/Return")) {
					posView.getChangeViewButton().setText("Sales");
					posView.getAddItemButton().setText("Enter Invoice#");
					posView.getBillNumber().setText("");
					k = 1;

				}
				else {
					posView.getChangeViewButton().setText("Exchange/Return");
					posView.getAddItemButton().setText("Add Item");
					int value = 0;
					try {
						ResultSet rs = null;
						PreparedStatement prep = databaseConnection.prepareStatement
								("select seq from sqlite_sequence where name=\"invoice\"");
						rs = prep.executeQuery();

						databaseConnection.setAutoCommit(false);
						databaseConnection.setAutoCommit(true);
						while (rs.next()){	
							value = rs.getInt("seq") + 1;
						}
						rs.close(); //close the query result table	
					} catch (SQLException e) {
						e.printStackTrace();
					}
					posView.getTable().setForeground(Color.black);

					posView.getBillNumber().setText("Invoice #" + value);
					k = 0;
				}
			}
		};


		submitButtonListener = new ActionListener() {
			public void actionPerformed(ActionEvent event) {

				MyTableModel k = (MyTableModel) posView.getTable().getModel();

				ArrayList<String> a0 = new ArrayList<String>();
				ArrayList<Integer> a1 = new ArrayList<Integer>();
				ArrayList<Integer> a2 = new ArrayList<Integer>();
				int t = 0;

				System.out.println("true or " + (k.getTill()));
				
				if (k.getTill() == -1) {
					for (int m = 0; m <k.getData().size()-1; m++) {
						String desc = (String) k.getData().get(m)[1];
						int price = ((Integer)  k.getData().get(m)[3]);
						int quan = (Integer) k.getData().get(m)[2];

						a0.add(desc);
						a1.add(price);
						a2.add(quan);
						t += price * quan;
					}
				}

				else {
					for (int m = 0; m <k.getTill()-2; m++) {
						String desc = (String) k.getData().get(m)[1];
						int price = ((Integer)  k.getData().get(m)[3]) * -1;
						int quan = (Integer) k.getData().get(m)[2];
						a0.add(desc);
						a1.add(price);
						a2.add(quan);
						t += price * quan;
					}

					for (int m = k.getTill()+1; m < k.getData().size()-3; m++) {
						String desc = (String) k.getData().get(m)[1];
						int price = ((Integer)  k.getData().get(m)[3]);
						int quan = (Integer) k.getData().get(m)[2];
						if (quan != 0) {
							a0.add(desc);
							a1.add(price);
							a2.add(quan);
							t += price * quan;
						}
					}

				}
				int value = 0;
				try {
					ResultSet rs = null;
					PreparedStatement prep = databaseConnection.prepareStatement
							("select seq from sqlite_sequence where name=\"invoice\"");
					rs = prep.executeQuery();

					databaseConnection.setAutoCommit(false);
					databaseConnection.setAutoCommit(true);
					while (rs.next()){	
						value = rs.getInt("seq") + 1;
					}
					rs.close(); //close the query result table	
				} catch (SQLException e) {
					e.printStackTrace();
				}

				if (value == 0) {
					value++;
				}

				System.out.println(a1);

				SimpleDateFormat sdf = new SimpleDateFormat(" dd-MMM-yyyy HH:mm:ss aaa");
				Date now = new Date();
				String strDate = sdf.format(now);


				Noina ew = new Noina(a0, a1, a2, t, strDate, value, "Invoice #");

				if (ew.doJob() == 1) {

					if (posView.getChangeViewButton().getText().equals("Sales")) {

						System.out.println("lists " +k.getValueAt(k.getRowCount()-3, 4));


						try {
							PreparedStatement prep = databaseConnection.prepareStatement
									("update invoice set total=? where i_id=?;");
							CurrencyAED ck = (CurrencyAED) k.getValueAt(k.getRowCount()-3, 4);
							prep.setInt(1, ck.getValue());
							prep.setInt(2, c);
							prep.addBatch();
							databaseConnection.setAutoCommit(false);
							prep.executeBatch();
							databaseConnection.setAutoCommit(true);

						} catch (SQLException e) {
							e.printStackTrace();
						}



						for (int j = (k.getTill()+1); j < (k.getRowCount()-3); j++) {

							String bar = (String) k.getData().get(j)[0];
							Integer quan = (Integer) k.getData().get(j)[2];

							PreparedStatement prep;
							try {

								prep = databaseConnection.prepareStatement
										("update containsTable set it_nums=? where (it_barcode=? AND in_id=?);");
								prep.setInt(1, quan);
								prep.setString(2, bar);
								prep.setInt(3, invoiceNum);
								prep.addBatch();
								databaseConnection.setAutoCommit(false);
								prep.executeBatch();
								databaseConnection.setAutoCommit(true);
							} catch (SQLException e) {
								e.printStackTrace();
							}

							if ((j - (k.getTill()-3)) <= 4) {

								try {
									int oldQua = (int) k.getData().get(j-k.getTill()-1)[2];
									int newQua = (int) k.getData().get(j)[2];
									int up = oldQua - newQua;
									prep = databaseConnection.prepareStatement
											("update inventory set item_quantity=item_quantity+? where item_barcode=?;");
									prep.setInt(1, up);
									prep.setString(2, bar);

									prep.addBatch();
									databaseConnection.setAutoCommit(false);
									prep.executeBatch();
									databaseConnection.setAutoCommit(true);

								} catch (SQLException e) {
									e.printStackTrace();
								}
							}

							else {
								bar = (String) k.getData().get(j)[0];
								quan = (Integer) k.getData().get(j)[2];
								try {
									prep = databaseConnection.prepareStatement
											("update inventory set item_quantity=item_quantity-? where item_barcode=?;");
									prep.setInt(1, quan);
									prep.setString(2, bar);

									prep.addBatch();
									databaseConnection.setAutoCommit(false);
									prep.executeBatch();
									databaseConnection.setAutoCommit(true);

								} catch (SQLException e) {
									e.printStackTrace();
								}	

							}

						}


						//posView.getTable().setModel(new MyTableModel());
						posView.tableReset();
						update();
						sdf = new SimpleDateFormat(" dd-MMM-yyyy HH;mm;ss aaa");
						strDate = sdf.format(now);
						try {
							copyFile(new File("noina"), new File("Backup//noina" + strDate));
						} catch (IOException e) {
							e.printStackTrace();
						}
						posView.getAddItemButton().setText("Enter Invoice#");
						revalidate();
						repaint();
						return;
					}

					try {
						PreparedStatement prep = databaseConnection.prepareStatement
								("insert into invoice (day, month, year, time, total) values(?, ?, ?, ?, ?);");
						prep.setInt(1, Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
						prep.setInt(2, Calendar.getInstance().get(Calendar.MONTH));
						prep.setInt(3, Calendar.getInstance().get(Calendar.YEAR));
						Calendar cal = Calendar.getInstance();
						sdf = new SimpleDateFormat("HH:mm:ss");
						prep.setString(4, sdf.format(cal.getTime()));
						k = (MyTableModel) posView.getTable().getModel();
						prep.setInt(5, ((CurrencyAED) k.getValueAt(k.getRowCount()-1, 4)).getValue());

						prep.addBatch();
						databaseConnection.setAutoCommit(false);
						prep.executeBatch();
						databaseConnection.setAutoCommit(true);

					} catch (SQLException e) {
						e.printStackTrace();
					}

					value = 0;
					try {
						ResultSet rs = null;
						PreparedStatement prep = databaseConnection.prepareStatement
								("SELECT last_insert_rowid()");
						rs = prep.executeQuery();

						databaseConnection.setAutoCommit(false);
						databaseConnection.setAutoCommit(true);
						while (rs.next()){	
							value = rs.getInt("last_insert_rowid()");
						}
						rs.close(); //close the query result table	
					} catch (SQLException e) {
						e.printStackTrace();
					}

					MyTableModel model = (MyTableModel)posView.getTable().getModel(); 
					int c = model.getRowCount() - 1;

					for (int j = 0; j < c; j++) {
						String bar = (String) model.getData().get(j)[0];
						String desc = (String) model.getData().get(j)[1];
						Integer quan = (Integer) model.getData().get(j)[2];
						Integer price = ((Integer) model.getData().get(j)[3]);

						PreparedStatement prep;
						try {
							prep = databaseConnection.prepareStatement
									("insert into containsTable values(?, ?, ?, ?, ?);");
							prep.setString(1, bar);
							prep.setInt(2, value);
							prep.setInt(3, quan);
							prep.setString(4, desc);
							prep.setInt(5, price);

							prep.addBatch();
							databaseConnection.setAutoCommit(false);
							prep.executeBatch();
							databaseConnection.setAutoCommit(true);
						} catch (SQLException e) {
							e.printStackTrace();
						}


						try {
							prep = databaseConnection.prepareStatement
									("update inventory set item_quantity=item_quantity-? where item_barcode=?;");
							prep.setInt(1, quan);
							prep.setString(2, bar);

							prep.addBatch();
							databaseConnection.setAutoCommit(false);
							prep.executeBatch();
							databaseConnection.setAutoCommit(true);

						} catch (SQLException e) {
							e.printStackTrace();
						}

					}


					//posView.getTable().setModel(new MyTableModel());

					posView.tableReset();
					update();
					sdf = new SimpleDateFormat(" dd-MMM-yyyy HH;mm;ss aaa");
					strDate = sdf.format(now);
					try {
						copyFile(new File("noina"), new File("Backup//noina" + strDate));
					} catch (IOException e) {
						e.printStackTrace();
					}

					posView.getBillNumber().setText("Invoice #" + (value + 1));
					revalidate();
					repaint();
				}

			}
		};

		posButtonListener = new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				menuView.getPosButton().setEnabled(false);
				menuView.getInventoryManButton().setEnabled(true);
				menuView.getReportsButton().setEnabled(true);
				menuView.getCashButton().setEnabled(true);


				layoutConstraints.gridx = 0;
				layoutConstraints.gridy = 0;
				layoutConstraints.gridwidth = 1;
				layoutConstraints.gridheight = 1;
				layoutConstraints.fill = GridBagConstraints.BOTH;
				layoutConstraints.insets = new Insets(0, 0, 0, 0);
				layoutConstraints.anchor = GridBagConstraints.EAST;
				layoutConstraints.weightx = 1.0;
				layoutConstraints.weighty = 0.0;
				layout.setConstraints(menuView, layoutConstraints);

				layoutConstraints.gridx = 0;
				layoutConstraints.gridy = 1;
				layoutConstraints.gridwidth = 1;
				layoutConstraints.gridheight = 5;
				layoutConstraints.fill = GridBagConstraints.BOTH;
				layoutConstraints.insets = new Insets(0, 0, 0, 0);
				layoutConstraints.anchor = GridBagConstraints.EAST;
				layoutConstraints.weightx = 1.0;
				layoutConstraints.weighty = 1.0;
				layout.setConstraints(inventoryView, layoutConstraints);
				layout.setConstraints(posView, layoutConstraints);
				layout.setConstraints(reportView, layoutConstraints);
				layout.setConstraints(cashView, layoutConstraints);
				remove(cashView);


				remove(inventoryView);
				remove(reportView);

				add(posView);

				info = 1;
				revalidate();
				repaint();
			}
		};

		inManButtonListener = new ActionListener() {
			public void actionPerformed(ActionEvent event) {		
				menuView.getPosButton().setEnabled(true);
				menuView.getInventoryManButton().setEnabled(false);
				menuView.getReportsButton().setEnabled(true);
				menuView.getCashButton().setEnabled(true);


				layoutConstraints.gridx = 0;
				layoutConstraints.gridy = 0;
				layoutConstraints.gridwidth = 1;
				layoutConstraints.gridheight = 1;
				layoutConstraints.fill = GridBagConstraints.BOTH;
				layoutConstraints.insets = new Insets(0, 0, 0, 0);
				layoutConstraints.anchor = GridBagConstraints.EAST;
				layoutConstraints.weightx = 1.0;
				layoutConstraints.weighty = 0.0;
				layout.setConstraints(menuView, layoutConstraints);

				layoutConstraints.gridx = 0;
				layoutConstraints.gridy = 1;
				layoutConstraints.gridwidth = 1;
				layoutConstraints.gridheight = 5;
				layoutConstraints.fill = GridBagConstraints.BOTH;
				layoutConstraints.insets = new Insets(0, 0, 0, 0);
				layoutConstraints.anchor = GridBagConstraints.EAST;
				layoutConstraints.weightx = 1.0;
				layoutConstraints.weighty = 1.0;
				layout.setConstraints(inventoryView, layoutConstraints);
				layout.setConstraints(posView, layoutConstraints);
				layout.setConstraints(reportView, layoutConstraints);
				layout.setConstraints(cashView, layoutConstraints);
				remove(cashView);


				remove(posView);

				remove(reportView);

				add(inventoryView);
				info = 2;
				revalidate();

				repaint();
			}
		};

		cashButtonListener = new ActionListener() {
			public void actionPerformed(ActionEvent event) {		
				menuView.getPosButton().setEnabled(true);
				menuView.getInventoryManButton().setEnabled(true);
				menuView.getReportsButton().setEnabled(true);
				menuView.getCashButton().setEnabled(false);


				layoutConstraints.gridx = 0;
				layoutConstraints.gridy = 0;
				layoutConstraints.gridwidth = 1;
				layoutConstraints.gridheight = 1;
				layoutConstraints.fill = GridBagConstraints.BOTH;
				layoutConstraints.insets = new Insets(0, 0, 0, 0);
				layoutConstraints.anchor = GridBagConstraints.EAST;
				layoutConstraints.weightx = 1.0;
				layoutConstraints.weighty = 0.0;
				layout.setConstraints(menuView, layoutConstraints);

				layoutConstraints.gridx = 0;
				layoutConstraints.gridy = 1;
				layoutConstraints.gridwidth = 1;
				layoutConstraints.gridheight = 5;
				layoutConstraints.fill = GridBagConstraints.BOTH;
				layoutConstraints.insets = new Insets(0, 0, 0, 0);
				layoutConstraints.anchor = GridBagConstraints.EAST;
				layoutConstraints.weightx = 1.0;
				layoutConstraints.weighty = 1.0;
				layout.setConstraints(inventoryView, layoutConstraints);
				layout.setConstraints(posView, layoutConstraints);
				layout.setConstraints(reportView, layoutConstraints);
				layout.setConstraints(cashView, layoutConstraints);

				remove(posView);
				remove(inventoryView);
				remove(reportView);

				add(cashView);

				int sales = 0;
				try {		
					String sqlQueryString =  "select sum(total) from invoice";
					reportView.getText().append(sqlQueryString + "\n");
					ResultSet rs = null;
					PreparedStatement prep = databaseConnection.prepareStatement
							(sqlQueryString);
					rs = prep.executeQuery();

					databaseConnection.setAutoCommit(false);
					databaseConnection.setAutoCommit(true);
					while (rs.next()){	
						sales = (rs.getInt("sum(total)"));
					}
					rs.close(); //close the query result table

				} catch (SQLException e) {
					e.printStackTrace();
				}

				int expenses = 0;
				try {		
					String sqlQueryString =  "select sum(exp_amount) from expenses";
					reportView.getText().append(sqlQueryString + "\n");
					ResultSet rs = null;
					PreparedStatement prep = databaseConnection.prepareStatement
							(sqlQueryString);
					rs = prep.executeQuery();

					databaseConnection.setAutoCommit(false);
					databaseConnection.setAutoCommit(true);
					while (rs.next()){	
						expenses = (rs.getInt("sum(exp_amount)"));
					}
					rs.close(); //close the query result table

				} catch (SQLException e) {
					e.printStackTrace();
				}

				int withdraw = 0;
				try {		
					String sqlQueryString =  "select sum(witdr_amount) from withdraw";
					reportView.getText().append(sqlQueryString + "\n");
					ResultSet rs = null;
					PreparedStatement prep = databaseConnection.prepareStatement
							(sqlQueryString);
					rs = prep.executeQuery();

					databaseConnection.setAutoCommit(false);
					databaseConnection.setAutoCommit(true);
					while (rs.next()){	
						withdraw = (rs.getInt("sum(witdr_amount)"));
					}
					rs.close(); //close the query result table

				} catch (SQLException e) {
					e.printStackTrace();
				}


				cashView.getTable().setModel(new java_sqlite_3005.Statement());
				java_sqlite_3005.Statement s = (java_sqlite_3005.Statement) cashView.getTable().getModel();

				DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
				centerRenderer.setHorizontalAlignment( JLabel.CENTER );
				cashView.getTable().getColumnModel().getColumn(1).setCellRenderer( centerRenderer );


				Object[] f = {"Sales", new CurrencyAED(sales)};
				s.getData().add(f);

				Object[] j = {"Expenses",  new CurrencyAED(expenses)};
				s.getData().add(j);

				Object[] l = {"Withdraw", new CurrencyAED(withdraw)};
				s.getData().add(l);

				int jj = sales - (expenses + withdraw);
				Object[] k = {"Cash", new CurrencyAED(jj)};
				s.getData().add(k);


				revalidate();
				repaint();
			}
		};

		repButtonListener = new ActionListener() {
			public void actionPerformed(ActionEvent event) {			
				menuView.getPosButton().setEnabled(true);
				menuView.getInventoryManButton().setEnabled(true);
				menuView.getReportsButton().setEnabled(false);
				menuView.getCashButton().setEnabled(true);


				layoutConstraints.gridx = 0;
				layoutConstraints.gridy = 0;
				layoutConstraints.gridwidth = 1;
				layoutConstraints.gridheight = 1;
				layoutConstraints.fill = GridBagConstraints.BOTH;
				layoutConstraints.insets = new Insets(0, 0, 0, 0);
				layoutConstraints.anchor = GridBagConstraints.EAST;
				layoutConstraints.weightx = 1.0;
				layoutConstraints.weighty = 0.0;
				layout.setConstraints(menuView, layoutConstraints);

				layoutConstraints.gridx = 0;
				layoutConstraints.gridy = 1;
				layoutConstraints.gridwidth = 1;
				layoutConstraints.gridheight = 5;
				layoutConstraints.fill = GridBagConstraints.BOTH;
				layoutConstraints.insets = new Insets(0, 0, 0, 0);
				layoutConstraints.anchor = GridBagConstraints.EAST;
				layoutConstraints.weightx = 1.0;
				layoutConstraints.weighty = 1.0;
				layout.setConstraints(inventoryView, layoutConstraints);
				layout.setConstraints(posView, layoutConstraints);
				layout.setConstraints(reportView, layoutConstraints);
				layout.setConstraints(cashView, layoutConstraints);
				remove(cashView);

				remove(inventoryView);
				remove(posView);
				add(reportView);
				revalidate();
				repaint();

				reportView.getText().setText("");

				try {		
					String sqlQueryString =  "select * from inventory ORDER BY item_quantity";
					reportView.getText().append(sqlQueryString + "\n");
					ResultSet rs = null;
					PreparedStatement prep = databaseConnection.prepareStatement
							(sqlQueryString);
					rs = prep.executeQuery();

					databaseConnection.setAutoCommit(false);
					databaseConnection.setAutoCommit(true);
					while (rs.next()){	
						Item j = new Item(rs.getString("item_barcode"),
								rs.getInt("item_quantity"),
								rs.getInt("item_price"), rs.getString("item_full_name")
								); 
						reportView.getText().append(j.toString() + "\n");
					}
					rs.close(); //close the query result table

				} catch (SQLException e) {
					e.printStackTrace();
				}


				try {		
					String sqlQueryString =  "select * from invoice";
					reportView.getText().append("\n" + sqlQueryString + "\n");
					ResultSet rs = null;
					PreparedStatement prep = databaseConnection.prepareStatement
							(sqlQueryString);
					rs = prep.executeQuery();

					databaseConnection.setAutoCommit(false);
					databaseConnection.setAutoCommit(true);
					while (rs.next()){	
						Invoice j = new Invoice(rs.getInt("i_id"),rs.getInt("day"),
								rs.getInt("month"),rs.getInt("year"),rs.getString("time"), 
								rs.getInt("total")); 
						reportView.getText().append(j.toString() + "\n");
					}
					rs.close(); //close the query result table

				} catch (SQLException e) {
					e.printStackTrace();
				}

				try {		
					String sqlQueryString =  "select * from containsTable";
					reportView.getText().append("\n" + sqlQueryString + "\n");
					ResultSet rs = null;
					PreparedStatement prep = databaseConnection.prepareStatement
							(sqlQueryString);
					rs = prep.executeQuery();

					databaseConnection.setAutoCommit(false);
					databaseConnection.setAutoCommit(true);
					while (rs.next()){	

						reportView.getText().append("Invoice #" + 
								rs.getInt("in_id") + " Item: " + rs.getString("it_barcode") + " Quantity " + rs.getInt("it_nums") + " Quantity " + rs.getInt("it_price") + "\n");
					}
					rs.close(); //close the query result table

				} catch (SQLException e) {
					e.printStackTrace();
				}

				try {		
					String sqlQueryString =  "select * from expenses";
					reportView.getText().append("\n" + sqlQueryString + "\n");
					ResultSet rs = null;
					PreparedStatement prep = databaseConnection.prepareStatement
							(sqlQueryString);
					rs = prep.executeQuery();

					databaseConnection.setAutoCommit(false);
					databaseConnection.setAutoCommit(true);
					while (rs.next()){	

						reportView.getText().append("Expense #" + 
								rs.getInt("exp_id") + " Amount: " + rs.getString("exp_amount") +
								" Description: " + rs.getString("exp_desc") + 
								" Date & Time: " + rs.getString("exp_date_time") +  "" +
								" By: " + rs.getString("exp_user") + 	"\n");
					}
					rs.close(); //close the query result table

				} catch (SQLException e) {
					e.printStackTrace();
				}

				try {		
					String sqlQueryString =  "select * from withdraw";
					reportView.getText().append("\n" + sqlQueryString + "\n");
					ResultSet rs = null;
					PreparedStatement prep = databaseConnection.prepareStatement
							(sqlQueryString);
					rs = prep.executeQuery();

					databaseConnection.setAutoCommit(false);
					databaseConnection.setAutoCommit(true);
					while (rs.next()){	

						reportView.getText().append("Withdraw #" + 
								rs.getInt("witdr_id") + " Amount: " + rs.getString("witdr_amount") +
								" Description: " + rs.getString("witdr_desc") + 
								" Date & Time: " + rs.getString("witdr_date_time") +  "" +
								" By: " + rs.getString("witdr_user") + 	"\n");
					}
					rs.close(); //close the query result table

				} catch (SQLException e) {
					e.printStackTrace();
				}
				

				try {		
					String sqlQueryString =  "select * from invoice";
					reportView.getText().append("\n" + "Today: " + "\n");
					ResultSet rs = null;
					PreparedStatement prep = databaseConnection.prepareStatement
							(sqlQueryString);
					rs = prep.executeQuery();

					databaseConnection.setAutoCommit(false);
					databaseConnection.setAutoCommit(true);
					int sum = 0;
					while (rs.next()){	
						String string = " " + rs.getInt("day") + "-" + (rs.getInt("month")+1) + 
								"-" + rs.getInt("year") +  " " + rs.getString("time");
						SimpleDateFormat sdf = new SimpleDateFormat(" dd-MM-yyyy HH:mm:ss");
						Date date = sdf.parse(string);
						long millis = System.currentTimeMillis() - 23 * 60 * 60 * 1000; 
					    Date d1 = new Date(millis);
					    
					    if ((d1.before(date)) || (d1.equals(date))) {
							Invoice j = new Invoice(rs.getInt("i_id"),rs.getInt("day"),
									rs.getInt("month"),rs.getInt("year"),rs.getString("time"), 
									rs.getInt("total")); 
							sum += rs.getInt("total");
							reportView.getText().append(j.toString() + "\n");
					    }
					}
					reportView.getText().append("\nToday's total AED " + sum + "\n");

					rs.close(); //close the query result table

				} catch (SQLException e) {
					e.printStackTrace();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		};


		searchButtonListener = new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				inventoryView.getSearchButton().setText("Scan Barcode");

				String query = "";

				query = JOptionPane.showInputDialog(null,
						"Scan Barcode");

				if (query == null)
					return;
				String sqlQueryString = "select * from inventory where (item_barcode = '" + query + "');";

				System.out.println(sqlQueryString);

				try {		
					ResultSet rs = null;
					PreparedStatement prep = databaseConnection.prepareStatement
							(sqlQueryString);
					rs = prep.executeQuery();

					while (!rs.isBeforeFirst()) {
						rs.close();
						query = JOptionPane.showInputDialog(null,
								"Invalid Barcode");
						sqlQueryString = "select * from inventory where (item_barcode = '" + query + "');";
						prep = databaseConnection.prepareStatement(sqlQueryString);
						rs = prep.executeQuery();
						if (query == null) {
							break;
						}
					}
					if (query == null) {
						return;
					}

					databaseConnection.setAutoCommit(false);
					databaseConnection.setAutoCommit(true);
					while (rs.next()){	

						inventoryView.getItemBarcode().setText("Barcode: " + rs.getString("item_barcode"));
						inventoryView.getItemQuantity().setText("Quantity: " + rs.getInt("item_quantity"));
						inventoryView.getItemPrice().setText("Price: AED " + rs.getInt("item_price"));
						inventoryView.getitemFullName().setText("Full Name: " + rs.getString("item_full_name"));
						itemBeingEdited = new Item(rs.getString("item_barcode"),
								rs.getInt("item_quantity"),
								rs.getInt("item_price"), rs.getString("item_full_name")
								); 
					}

					inventoryView.getItemEditButton().setEnabled(true);
					inventoryView.getItemDeleteButton().setEnabled(true);
					inventoryView.getItemNewButton().setEnabled(true);

					rs.close(); //close the query result table

				} 
				catch (SQLException e) {
					e.printStackTrace();
				}
			}
		};

		addButtonListener = new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				if(posView.getChangeViewButton().getText().equals("Sales")) {
					if (posView.getAddItemButton().getText().equals("Enter Invoice#")) {
						String query = "";

						query = JOptionPane.showInputDialog(null,
								"Invoice#:");

						if (query == null)
							return;
						String sqlQueryString = "select * from containsTable where (in_id = '" + query + "');";

						System.out.println(sqlQueryString);

						try {		
							ResultSet rs = null;
							PreparedStatement prep = databaseConnection.prepareStatement
									(sqlQueryString);
							rs = prep.executeQuery();

							while (!rs.isBeforeFirst()) {
								rs.close();
								query = JOptionPane.showInputDialog(null,
										"Invalid Invoice#");
								sqlQueryString = "select * from containsTable where (in_id = '" + query + "');";
								prep = databaseConnection.prepareStatement(sqlQueryString);
								rs = prep.executeQuery();
								if (query == null) {
									break;
								}
							}
							if (query == null) {
								return;
							}

							c = Integer.parseInt(query);
							MyTableModel m = (MyTableModel) posView.getTable().getModel();
							databaseConnection.setAutoCommit(false);
							databaseConnection.setAutoCommit(true);
							int f = 0;
							while (rs.next()){	
								int k = rs.getInt("it_nums") * rs.getInt("it_price");
								Object[] a = {rs.getString("it_barcode"), rs.getString("it_desc"),
										rs.getInt("it_nums"), new Integer(rs.getInt("it_price")),
										new CurrencyAED(k)};
								m.updateTotal(a);							
								f++;
							}
							rs.close(); //close the query result table
							numbers = f+2;
							m.setTill(numbers);
							posView.getBillNumber().setText("Return/Exchange\nInvoice#" + query);
							m.enterBlank();


							prep = databaseConnection.prepareStatement
									(sqlQueryString);
							rs = prep.executeQuery();
							databaseConnection.setAutoCommit(false);
							databaseConnection.setAutoCommit(true);
							while (rs.next()){	
								int k = rs.getInt("it_nums") * rs.getInt("it_price");
								Object[] a = {rs.getString("it_barcode"), rs.getString("it_desc"),
										rs.getInt("it_nums"), new Integer(rs.getInt("it_price")),
										new CurrencyAED(k)};
								m.updateTotalTill(a);
							}
							rs.close(); //close the query result table

						} 
						catch (SQLException e) {
							e.printStackTrace();
						}

						posView.getAddItemButton().setText("Add Item");

						invoiceNum = Integer.parseInt(query);
						disableListeners();
						enableListeners();
						revalidate();
						repaint();
						return;
					}
					else {
						inventoryView.getSearchButton().setText("Scan Barcode");

						String query = "";

						query = JOptionPane.showInputDialog(null,
								"Scan Barcode");

						if (query == null)
							return;
						String sqlQueryString = "select * from inventory where (item_barcode = '" + query + "');";

						System.out.println(sqlQueryString);

						try {		
							ResultSet rs = null;
							PreparedStatement prep = databaseConnection.prepareStatement
									(sqlQueryString);
							rs = prep.executeQuery();

							while (!rs.isBeforeFirst()) {
								rs.close();
								query = JOptionPane.showInputDialog(null,
										"Invalid Barcode");
								sqlQueryString = "select * from inventory where (item_barcode = '" + query + "');";
								prep = databaseConnection.prepareStatement(sqlQueryString);
								rs = prep.executeQuery();
								if (query == null) {
									break;
								}
							}

							if (query == null) {
								return;
							}
							MyTableModel k = (MyTableModel) posView.getTable().getModel();

							databaseConnection.setAutoCommit(false);
							databaseConnection.setAutoCommit(true);
							Item x = new Item("");
							while (rs.next()){	
								x = new Item(rs.getString("item_barcode"),
										rs.getInt("item_quantity"),
										rs.getInt("item_price"), rs.getString("item_full_name")
										); 
							}
							Object[] a = {x.getBarcode(), x.getFullName(), new Integer(1), new Integer(x.getPrice()), new CurrencyAED(x.getPrice())};

							for (int y = 0; y < k.getData().size(); y++) {
								if(k.getData().get(y)[0].equals(x.getBarcode())) {
									JOptionPane.showMessageDialog(null, "Item already exists in table adjust quantities");
									return;
								}
							}

							k.updateTotalTill(a);
							rs.close(); 
						}
						catch (SQLException e) {
							e.printStackTrace();
						}


						disableListeners();
						enableListeners();
						revalidate();
						repaint();

						return;
					}

				}

				inventoryView.getSearchButton().setText("Scan Barcode");

				String query = "";

				query = JOptionPane.showInputDialog(null,
						"Scan Barcode");

				if (query == null)
					return;
				String sqlQueryString = "select * from inventory where (item_barcode = '" + query + "');";

				System.out.println(sqlQueryString);

				try {		
					ResultSet rs = null;
					PreparedStatement prep = databaseConnection.prepareStatement
							(sqlQueryString);
					rs = prep.executeQuery();

					while (!rs.isBeforeFirst()) {
						rs.close();
						query = JOptionPane.showInputDialog(null,
								"Invalid Barcode");
						sqlQueryString = "select * from inventory where (item_barcode = '" + query + "');";
						prep = databaseConnection.prepareStatement(sqlQueryString);
						rs = prep.executeQuery();
						if (query == null) {
							break;
						}
					}

					if (query == null) {
						return;
					}
					MyTableModel k = (MyTableModel) posView.getTable().getModel();

					databaseConnection.setAutoCommit(false);
					databaseConnection.setAutoCommit(true);
					Item x = new Item("");
					while (rs.next()){	
						x = new Item(rs.getString("item_barcode"),
								rs.getInt("item_quantity"),
								rs.getInt("item_price"), rs.getString("item_full_name")
								); 
					}
					Object[] a = {x.getBarcode(), x.getFullName(), new Integer(1), new Integer(x.getPrice()), new CurrencyAED(x.getPrice())};

					for (int y = 0; y < k.getData().size(); y++) {
						if(k.getData().get(y)[0].equals(x.getBarcode())) {
							JOptionPane.showMessageDialog(null, "Item already exists in table adjust quantities");
							return;
						}
					}
					//HERE
					//	for (int j = 0; j < 50; j++)
					k.updateTotal(a);

					rs.close(); //close the query result table
					revalidate();
					repaint();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		};

		deleteButtonListener = new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				String passwordValue = "";
				int result = 1000;
				//Here is some validation code
				while (true) {
					if (passwordValue.equals("noina1968")) {
						break;
					}
					if (result == JOptionPane.CANCEL_OPTION) {
						return;
					}
					JLabel jPassword = new JLabel("Password");
					JTextField password = new JPasswordField();
					Object[] ob = {jPassword, password};
					result = JOptionPane.showConfirmDialog(null, ob, "Enter Your Password", JOptionPane.OK_CANCEL_OPTION);
					passwordValue = password.getText();
					if (passwordValue.equals("noina1968")) {
						break;
					}
					if (result == JOptionPane.CANCEL_OPTION) {
						return;
					}
				}
				try {
					PreparedStatement prep = databaseConnection.prepareStatement
							("delete from inventory where item_barcode=?;");
					prep.setString(1, itemBeingEdited.getBarcode().replaceAll("'","''"));

					prep.addBatch();
					databaseConnection.setAutoCommit(false);
					prep.executeBatch();
					databaseConnection.setAutoCommit(true);

				} catch (SQLException e) {
					e.printStackTrace();
				}

				SimpleDateFormat sdf = new SimpleDateFormat(" dd-MMM-yyyy HH;mm;ss aaa");
				Date now = new Date();
				String strDate = sdf.format(now);
				try {
					copyFile(new File("noina"), new File("Backup//noina" + strDate));
				} catch (IOException e) {
					e.printStackTrace();
				}

				update();
				updateDelete();


			}
		};


		editButtonListener = new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				ItemEditDialog dialog = new ItemEditDialog(thisFrame, thisFrame, "Edit Item", true, itemBeingEdited);         
				dialog.setVisible(true);
			}
		};




		newButtonListener = new ActionListener() {
			public void actionPerformed(ActionEvent event) {

				NewItemDialog dialog = new NewItemDialog(thisFrame, thisFrame, "New Item", true, itemBeingEdited);         
				dialog.setVisible(true);
			}
		};

		Toolkit tk = Toolkit.getDefaultToolkit();
		int xSize = ((int) tk.getScreenSize().getWidth());
		int ySize = ((int) tk.getScreenSize().getHeight());
		setSize(xSize, ySize);

		update();

		disableListeners();
		enableListeners();
	}

	private void enableListeners() {
		inventoryView.getSearchButton().addActionListener(searchButtonListener);
		inventoryView.getItemEditButton().addActionListener(editButtonListener);
		inventoryView.getItemNewButton().addActionListener(newButtonListener);
		inventoryView.getItemDeleteButton().addActionListener(deleteButtonListener);

		menuView.getPosButton().addActionListener(posButtonListener);
		menuView.getInventoryManButton().addActionListener(inManButtonListener);
		menuView.getReportsButton().addActionListener(repButtonListener);

		posView.getTable().getModel().addTableModelListener(this);
		posView.getAddItemButton().addActionListener(addButtonListener);

		posView.getsubmitButton().addActionListener(submitButtonListener);
		posView.getChangeViewButton().addActionListener(changeViewButtonListener);
		menuView.getCashButton().addActionListener(cashButtonListener);

		cashView.getAddExpenses().addActionListener(expensesListener);
		cashView.getWithdraw().addActionListener(withdrawListener);

	}


	public void tableChanged(TableModelEvent e) {
		MyTableModel model = (MyTableModel)e.getSource();

		if (k == 1) {

			Integer total = 0;
			for (int i = model.getTill()+1; i < model.getRowCount()-3; i++) {
				Integer q = (Integer) model.getValueAt(i, 2);
				Integer cp = (Integer) model.getValueAt(i, 3);
				model.setValueAt(new CurrencyAED(cp*q), i, 4);
				total += cp*q;
			}	
			model.getData().remove( model.getRowCount()-1);
			model.getData().remove( model.getRowCount()-1);
			model.getData().remove( model.getRowCount()-1);

			Object[] t = {"", "New Total", "", "", new CurrencyAED(total)};
			model.getData().add(t);
			Object[] j = {"", "Old Total", "", "", model.getValueAt(model.getTill()-2, 4)};
			model.getData().add(j);

			int m = ((CurrencyAED)model.getValueAt(model.getRowCount()-1, 4)).getValue();
			int f = ((CurrencyAED)model.getValueAt(model.getRowCount()-2, 4)).getValue();
			Object[] k = {"", "Difference", "", "",  new CurrencyAED(f-m)};
			model.getData().add(k);

			return;
		}

		Integer total = 0;
		for (int i = 0; i < model.getRowCount()-1; i++) {
			Integer q = ((Integer) model.getValueAt(i, 2));
			Integer cp = (Integer) model.getValueAt(i, 3);
			model.setValueAt(new CurrencyAED(cp*q), i, 4);
			total += cp*q;
		}	
		model.getData().remove( model.getRowCount()-1);
		Object[] t = {"", "", "", "", new CurrencyAED(total)};
		model.getData().add(t);
		
		revalidate();
		repaint();
	}


	private void disableListeners() {
		inventoryView.getSearchButton().removeActionListener(searchButtonListener);
		inventoryView.getItemEditButton().removeActionListener(editButtonListener);
		inventoryView.getItemNewButton().removeActionListener(newButtonListener);
		inventoryView.getItemDeleteButton().removeActionListener(deleteButtonListener);

		menuView.getPosButton().removeActionListener(posButtonListener);
		menuView.getInventoryManButton().removeActionListener(inManButtonListener);
		menuView.getReportsButton().removeActionListener(repButtonListener);

		menuView.getCashButton().removeActionListener(cashButtonListener);

		posView.getAddItemButton().removeActionListener(addButtonListener);

		posView.getsubmitButton().removeActionListener(submitButtonListener);
		posView.getChangeViewButton().removeActionListener(changeViewButtonListener);

		cashView.getAddExpenses().removeActionListener(expensesListener);
		cashView.getWithdraw().removeActionListener(withdrawListener);
		posView.getTable().getModel().removeTableModelListener(this);


	}	


	public void updateEdit() {

		String sqlQueryString = "select * from inventory where (item_barcode = '" + itemBeingEdited.getBarcode() + "');";

		try {		
			ResultSet rs = null;
			PreparedStatement prep = databaseConnection.prepareStatement
					(sqlQueryString);
			rs = prep.executeQuery();

			databaseConnection.setAutoCommit(false);
			databaseConnection.setAutoCommit(true);
			while (rs.next()){	

				inventoryView.getItemBarcode().setText("Barcode: " + rs.getString("item_barcode"));
				inventoryView.getItemQuantity().setText("Quantity: " + rs.getInt("item_quantity"));
				inventoryView.getItemPrice().setText("Price: AED " + rs.getInt("item_price"));
				inventoryView.getitemFullName().setText("Full Name: " + rs.getString("item_full_name"));
				itemBeingEdited = new Item(rs.getString("item_barcode"),
						rs.getInt("item_quantity"),
						rs.getInt("item_price"), rs.getString("item_full_name")
						); 
				System.out.println(sqlQueryString + " new quantity " + rs.getInt("item_quantity"));
			}			
			rs.close(); //close the query result table

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void updateDelete() {
		inventoryView.getItemBarcode().setText("Barcode: ");
		inventoryView.getItemQuantity().setText("Quantity: ");
		inventoryView.getItemPrice().setText("Price: AED ");
		inventoryView.getitemFullName().setText("Full Name: ");
		itemBeingEdited = null;
		inventoryView.getItemEditButton().setEnabled(false);
		inventoryView.getItemDeleteButton().setEnabled(false);
	}
	public void updateNew() {

		String sqlQueryString = "select * from inventory where (item_barcode = '" + itemBeingEdited.getBarcode() + "');";

		try {		
			ResultSet rs = null;
			PreparedStatement prep = databaseConnection.prepareStatement
					(sqlQueryString);
			rs = prep.executeQuery();

			databaseConnection.setAutoCommit(false);
			databaseConnection.setAutoCommit(true);
			while (rs.next()){	

				inventoryView.getItemBarcode().setText("Barcode: " + rs.getString("item_barcode"));
				inventoryView.getItemQuantity().setText("Quantity: " + rs.getInt("item_quantity"));
				inventoryView.getItemPrice().setText("Price: AED " + rs.getInt("item_price"));
				inventoryView.getitemFullName().setText("Full Name: " + rs.getString("item_full_name"));
				itemBeingEdited = new Item(rs.getString("item_barcode"),
						rs.getInt("item_quantity"),
						rs.getInt("item_price"), rs.getString("item_full_name")
						); 

			}

			inventoryView.getItemEditButton().setEnabled(true);
			inventoryView.getItemDeleteButton().setEnabled(true);	
			rs.close(); //close the query result table

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Update the components
	private void update() {
		disableListeners();
		enableListeners();
	}

	@Override
	public void dialogFinished(DialogClient.operation requestedOperation) {

		if(requestedOperation == DialogClient.operation.EXPENSE){
			addExpense(cc.getWitdr_amount(), cc.getWitdr_desc(), cc.getWitdr_user());
		}
		if(requestedOperation == DialogClient.operation.WITHDRAW){
			addWithdraw(cc.getWitdr_amount(), cc.getWitdr_desc(), cc.getWitdr_user());
		}
		if(requestedOperation == DialogClient.operation.UPDATE){
			//TO DO
			//update song data in database
			System.out.println("UPDATE: " + itemBeingEdited  + " where " + itemBeingEdited.getQuantity());
			try {
				PreparedStatement prep = databaseConnection.prepareStatement
						("update inventory set item_quantity=?, item_price=?, " +
								"item_full_name=? where item_barcode=?;");
				prep.setString(1, "" + itemBeingEdited.getQuantity());
				prep.setString(2, "" + itemBeingEdited.getPrice());
				prep.setString(3, itemBeingEdited.getFullName().replaceAll("'","''"));
				prep.setString(4, itemBeingEdited.getBarcode().replaceAll("'","''"));

				prep.addBatch();
				databaseConnection.setAutoCommit(false);
				prep.executeBatch();
				databaseConnection.setAutoCommit(true);

			} catch (SQLException e) {
				e.printStackTrace();
			}

			SimpleDateFormat sdf = new SimpleDateFormat(" dd-MMM-yyyy HH;mm;ss aaa");
			Date now = new Date();
			String strDate = sdf.format(now);
			try {
				copyFile(new File("noina"), new File("Backup//noina" + strDate));
				copyFile(new File("noina"), new File("c:\\Backup//noina" + strDate));

			} catch (IOException e) {
				e.printStackTrace();
			}

			update();
			updateEdit();
		}
		if(requestedOperation == DialogClient.operation.ADD){

			int value = 0;
			try {
				ResultSet rs = null;
				PreparedStatement prep = databaseConnection.prepareStatement
						("select seq from sqlite_sequence where name=\"expenses\"");
				rs = prep.executeQuery();

				databaseConnection.setAutoCommit(false);
				databaseConnection.setAutoCommit(true);
				while (rs.next()){	
					value = rs.getInt("seq") + 1;
				}
				rs.close(); //close the query result table	
			} catch (SQLException e) {
				e.printStackTrace();
			}

			if (value == 0) {
				value++;
			}
			SimpleDateFormat sdf = new SimpleDateFormat(" dd-MMM-yyyy HH:mm:ss aaa");
			Date now = new Date();
			String strDate = sdf.format(now);
			ExpenseWithdraw ew = new ExpenseWithdraw("" + itemBeingEdited.getBarcode(),
					"" + itemBeingEdited.getPrice(), " " + "Admin", itemBeingEdited.getPrice(), strDate, value, "Add Stock");
			if (ew.doJob() == 1) {

				try {
					PreparedStatement prep = databaseConnection.prepareStatement
							("update inventory set item_quantity=? where item_barcode=?;");
					prep.setString(1, "" + (itemBeingEdited.getQuantity() + itemBeingEdited.getPrice()));
					prep.setString(2, itemBeingEdited.getBarcode().replaceAll("'","''"));

					prep.addBatch();
					databaseConnection.setAutoCommit(false);
					prep.executeBatch();
					databaseConnection.setAutoCommit(true);

				} catch (SQLException e) {
					e.printStackTrace();
				}

				sdf = new SimpleDateFormat(" dd-MMM-yyyy HH;mm;ss aaa");
				strDate = sdf.format(now);
				try {
					copyFile(new File("noina"), new File("Backup//noina" + strDate));
					copyFile(new File("noina"), new File("c:\\Backup//noina" + strDate));

				} catch (IOException e) {
					e.printStackTrace();
				}

				update();
				updateNew();
			}
		}
		else if(requestedOperation == DialogClient.operation.INVALID_ID_UPDATE){
			System.out.println("Invalid Key");
		}
	}

	public static void copyFile( File from, File to ) throws IOException {
		Files.copy( from.toPath(), to.toPath() );
	}


	public void addExpense(int am, String desc, String us) {

		int value = 0;
		try {
			ResultSet rs = null;
			PreparedStatement prep = databaseConnection.prepareStatement
					("select seq from sqlite_sequence where name=\"expenses\"");
			rs = prep.executeQuery();

			databaseConnection.setAutoCommit(false);
			databaseConnection.setAutoCommit(true);
			while (rs.next()){	
				value = rs.getInt("seq") + 1;
			}
			rs.close(); //close the query result table	
		} catch (SQLException e) {
			e.printStackTrace();
		}

		if (value == 0) {
			value++;
		}
		SimpleDateFormat sdf = new SimpleDateFormat(" dd-MMM-yyyy HH:mm:ss aaa");
		Date now = new Date();
		String strDate = sdf.format(now);
		ExpenseWithdraw ew = new ExpenseWithdraw(desc, "" + am, us, am, strDate, value, "Expense");
		if (ew.doJob() == 1) {


			try {
				PreparedStatement prep = databaseConnection.prepareStatement
						("insert into expenses(exp_amount, exp_date_time, exp_desc, exp_user) values(?, ?, ?, ?);");
				prep.setInt(1, am);
				prep.setString(3, desc);
				Calendar cal = Calendar.getInstance();
				sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				prep.setString(2, sdf.format(cal.getTime()));
				prep.setString(4, us);
				prep.addBatch();
				databaseConnection.setAutoCommit(false);
				prep.executeBatch();
				databaseConnection.setAutoCommit(true);

			} catch (SQLException e) {
				e.printStackTrace();
			}

			sdf = new SimpleDateFormat(" dd-MMM-yyyy HH;mm;ss aaa");
			strDate = sdf.format(now);
			try {
				copyFile(new File("noina"), new File("Backup//noina" + strDate));
				copyFile(new File("noina"), new File("c:\\Backup//noina" + strDate));

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public void addWithdraw(int am, String desc, String us) {


		int value = 0;
		try {
			ResultSet rs = null;
			PreparedStatement prep = databaseConnection.prepareStatement
					("select seq from sqlite_sequence where name=\"withdraw\"");
			rs = prep.executeQuery();

			databaseConnection.setAutoCommit(false);
			databaseConnection.setAutoCommit(true);
			while (rs.next()){	
				value = rs.getInt("seq") + 1;
			}
			rs.close(); //close the query result table	
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (value == 0) {
			value++;
		}

		SimpleDateFormat sdf = new SimpleDateFormat(" dd-MMM-yyyy HH:mm:ss aaa");
		Date now = new Date();
		String strDate = sdf.format(now);
		ExpenseWithdraw ew = new ExpenseWithdraw(desc, "" + am, us, am, strDate, value, "Withdraw");
		if (ew.doJob() == 1) {

			try {
				PreparedStatement prep = databaseConnection.prepareStatement
						("insert into withdraw(witdr_amount, witdr_date_time, witdr_desc, witdr_user) values(?, ?, ?, ?);");
				prep.setInt(1, am);
				prep.setString(3, desc);
				Calendar cal = Calendar.getInstance();
				sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				prep.setString(2, sdf.format(cal.getTime()));
				prep.setString(4, us);
				prep.addBatch();
				databaseConnection.setAutoCommit(false);
				prep.executeBatch();
				databaseConnection.setAutoCommit(true);

			} catch (SQLException e) {
				e.printStackTrace();
			}

			sdf = new SimpleDateFormat(" dd-MMM-yyyy HH;mm;ss aaa");
			strDate = sdf.format(now);
			try {
				copyFile(new File("noina"), new File("Backup//noina" + strDate));
				copyFile(new File("noina"), new File("c:\\Backup//noina" + strDate));

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	@Override
	public void dialogCancelled() {
		update();		
	}
}