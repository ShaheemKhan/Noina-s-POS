package java_sqlite_3005;

public class Cash {
	/*
	 * This class represents a fake book
	 */

	int witdr_amount;
	String witdr_date_time;
	String witdr_desc;
	String witdr_user;	
	
	public Cash () {
		witdr_amount = 0; 
		witdr_date_time = "";
		witdr_desc = "";
		witdr_user = "";
	}
	public int getWitdr_amount() {
		return witdr_amount;
	}
	public void setWitdr_amount(int witdr_amount) {
		this.witdr_amount = witdr_amount;
	}
	public String getWitdr_date_time() {
		return witdr_date_time;
	}
	public void setWitdr_date_time(String witdr_date_time) {
		this.witdr_date_time = witdr_date_time;
	}
	public String getWitdr_desc() {
		return witdr_desc;
	}
	public void setWitdr_desc(String witdr_desc) {
		this.witdr_desc = witdr_desc;
	}
	public String getWitdr_user() {
		return witdr_user;
	}
	public void setWitdr_user(String witdr_user) {
		this.witdr_user = witdr_user;
	}
	public Cash(int bc, String sn, String ty, String si){ 
		witdr_amount = bc; 
		witdr_date_time = sn;
		witdr_desc = ty;
		witdr_user = si;
	}

}
