package java_sqlite_3005;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.MatteBorder;

public class CashPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private JTable 		table;

	private JButton 	addExpenses;
	private JButton		withdraw;


	public Font getUIFont() {
		return UIFont;
	}
	


	public JButton getAddExpenses() {
		return addExpenses;
	}

	public JButton getWithdraw() {
		return withdraw;
	}



	private Font UIFont = new Font("Courier New", Font.BOLD, 16);

	// These are the get methods that are used to access the components

	// This is the default constructor
	public CashPanel(){
		super();

		// Use a GridBagLayout (lotsa fun)
		GridBagLayout layout = new GridBagLayout();
		GridBagConstraints layoutConstraints = new GridBagConstraints();
		setLayout(layout);
		
		addExpenses = new JButton("Add Expenses");
		layoutConstraints.gridx = 0;
		layoutConstraints.gridy = 0;
		layoutConstraints.gridwidth = 1;
		layoutConstraints.gridheight = 1;
		layoutConstraints.fill = GridBagConstraints.BOTH;
		layoutConstraints.insets = new Insets(0, 0, 0, 0);
		layoutConstraints.anchor = GridBagConstraints.EAST;
		layoutConstraints.weightx = 1.0;
		layoutConstraints.weighty = 0.0;
		layout.setConstraints(addExpenses, layoutConstraints);
		add(addExpenses);
		
		withdraw = new JButton("Withdraw");
		layoutConstraints.gridx = 1;
		layoutConstraints.gridy = 0;
		layoutConstraints.gridwidth = 1;
		layoutConstraints.gridheight = 1;
		layoutConstraints.fill = GridBagConstraints.BOTH;
		layoutConstraints.insets = new Insets(0, 0, 0, 0);
		layoutConstraints.anchor = GridBagConstraints.EAST;
		layoutConstraints.weightx = 1.0;
		layoutConstraints.weighty = 0.0;
		layout.setConstraints(withdraw, layoutConstraints);
		add(withdraw);
		
	
	    table = new JTable(new java_sqlite_3005.Statement());

	    JScrollPane jScrollPane1 = new JScrollPane(table);
	    jScrollPane1.setViewportView(table);
	    table.setFont(new Font("Times New Roman", Font.PLAIN, 20));
	    table.setRowHeight(30);	
		
	    table.setShowGrid(true);
	    Color color = Color.black;
	    MatteBorder border = new MatteBorder(1, 1, 0, 0, color);
	    table.setBorder(border);
	    table.setGridColor(color);
		table.setFillsViewportHeight(true);
	    table.setTableHeader(null);

	    
		 
		layoutConstraints.gridx = 0;
		layoutConstraints.gridy = 1;
		layoutConstraints.gridwidth = 3;
		layoutConstraints.gridheight = 2;
		layoutConstraints.fill = GridBagConstraints.BOTH;
		layoutConstraints.insets = new Insets(0, 0, 0, 0);
		layoutConstraints.anchor = GridBagConstraints.EAST;
		layoutConstraints.weightx = 1.0;
		layoutConstraints.weighty = 1.0;
		layout.setConstraints(table, layoutConstraints);
		
		add(table);
		
	}
	
	public JTable getTable() {
		return table;
	}


}